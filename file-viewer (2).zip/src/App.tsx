import React, { useEffect, useMemo, useState } from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { AboutView } from './components/AboutView';
import { AuthViews } from './components/AuthViews';
import { TrackIllustration } from './components/ConceptArtwork';
import { InteractiveSandbox } from './components/InteractiveSandbox';
import { PageView, PortalNavbar } from './components/PortalNavbar';
import { PushMenuDrawer } from './components/PushMenuDrawer';
import { TrackId, getLearningTracks } from './data/learningTracks';
import { Language, TRANSLATIONS } from './i18n/translations';

export default function App() {
  const [language, setLanguage] = useState<Language>('am');
  const [menuOpen, setMenuOpen] = useState<boolean>(false);
  const [isDark, setIsDark] = useState<boolean>(false);
  const [userName, setUserName] = useState<string | null>('አትንኩት');
  const [history, setHistory] = useState<PageView[]>(['home']);
  const [activeTrackId, setActiveTrackId] = useState<TrackId>('html');
  const [completedTracks, setCompletedTracks] = useState<Set<TrackId>>(
    () => new Set(['html'])
  );

  const t = TRANSLATIONS[language];
  const tracks = useMemo(() => getLearningTracks(language), [language]);
  const currentView = history[history.length - 1];

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [isDark]);

  // Keep <html lang="..."> and document title synced with active language
  useEffect(() => {
    document.documentElement.lang = language;
    document.title = `${t.brand} — ${t.companyName}`;
  }, [language, t.brand, t.companyName]);

  const navigate = (view: PageView) => {
    if (view === 'php') setActiveTrackId('php');
    if (view === 'mysql') setActiveTrackId('mysql');
    if (view === 'learn' && (activeTrackId === 'php' || activeTrackId === 'mysql')) {
      setActiveTrackId('html');
    }

    setHistory((prev) => {
      if (prev[prev.length - 1] === view) return prev;
      return [...prev, view];
    });
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenTrack = (id: TrackId) => {
    setActiveTrackId(id);
    if (id === 'php') {
      navigate('php');
    } else if (id === 'mysql') {
      navigate('mysql');
    } else {
      navigate('learn');
    }
  };

  const handleBack = () => {
    setHistory((prev) => (prev.length > 1 ? prev.slice(0, -1) : prev));
  };

  const toggleTrackComplete = (id: TrackId) => {
    setCompletedTracks((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const basicThreeTracks = tracks.filter(
    (item) => item.id === 'html' || item.id === 'css' || item.id === 'js'
  );

  const backendTracks = tracks.filter(
    (item) => item.id === 'php' || item.id === 'mysql'
  );

  const showcaseTracks: TrackId[] = ['html', 'css', 'js'];

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <PortalNavbar
        currentView={currentView}
        menuOpen={menuOpen}
        canGoBack={history.length > 1}
        isDark={isDark}
        userName={userName}
        language={language}
        t={t}
        onChangeLanguage={setLanguage}
        onToggleMenu={() => setMenuOpen((o) => !o)}
        onNavigate={navigate}
        onBack={handleBack}
        onToggleTheme={() => setIsDark((d) => !d)}
        onLogout={() => {
          setUserName(null);
          navigate('home');
        }}
      />

      <PushMenuDrawer
        open={menuOpen}
        currentView={currentView}
        completedCount={completedTracks.size}
        totalCount={tracks.length}
        language={language}
        t={t}
        onChangeLanguage={setLanguage}
        onSelect={navigate}
        onClose={() => setMenuOpen(false)}
      />

      <div
        id="main"
        className={`flex-1 flex flex-col transition-[margin] duration-200 ease-out ${
          menuOpen ? 'lg:ml-[280px]' : 'ml-0'
        }`}
      >
        <main className="flex-1">
          {currentView === 'home' && (
            <div className="max-w-6xl mx-auto px-4 md:px-8 py-10 md:py-14 space-y-14">
              {/* Hero Section */}
              <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
                <div className="lg:col-span-7 flex flex-col justify-center space-y-5">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                    <span>{t.companyName}</span>
                    <span aria-hidden="true">·</span>
                    <span>{userName ? t.greetingSignedIn(userName) : t.greetingGuest}</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">
                      {t.lessonsCompletedOf(completedTracks.size, tracks.length)}
                    </span>
                  </div>

                  <h1 className="font-display text-3xl md:text-5xl font-bold tracking-tight text-slate-900 dark:text-white leading-[1.18] text-balance">
                    {t.heroTitle}
                  </h1>

                  <p className="text-base md:text-lg text-slate-600 dark:text-slate-300 max-w-[60ch] leading-relaxed">
                    {t.heroSubtitle}
                  </p>

                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    <button
                      type="button"
                      onClick={() => handleOpenTrack('html')}
                      className="px-5 py-2.5 rounded-lg text-sm font-semibold text-white bg-emerald-700 hover:bg-emerald-800 dark:bg-emerald-600 dark:hover:bg-emerald-500 transition-colors inline-flex items-center gap-2 whitespace-nowrap"
                    >
                      <span>{t.startLearnClass}</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => navigate('more-home')}
                      className="px-5 py-2.5 rounded-lg text-sm font-medium border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors whitespace-nowrap"
                    >
                      {t.exploreCurriculum}
                    </button>
                  </div>
                </div>

                {/* Visual Showcase Panel */}
                <div className="lg:col-span-5 grid grid-cols-1 gap-3.5">
                  {t.showcaseItems.map((item, idx) => {
                    const trackId = showcaseTracks[idx];
                    return (
                      <button
                        key={trackId}
                        type="button"
                        onClick={() => handleOpenTrack(trackId)}
                        className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-emerald-500/60 transition-colors flex items-center gap-4 text-left"
                      >
                        <div className="w-28 h-18 shrink-0 overflow-hidden rounded-lg">
                          <TrackIllustration trackId={trackId} />
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs text-slate-500 dark:text-slate-400">
                            {item.kicker}
                          </div>
                          <div className="font-display text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                            {item.title}
                          </div>
                          <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 truncate">
                            {item.desc}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </section>

              <hr className="border-slate-200 dark:border-slate-800" />

              {/* Core Frontend Trio */}
              <section className="space-y-6">
                <div className="flex flex-wrap items-end justify-between gap-4">
                  <div>
                    <div className="text-xs font-medium text-emerald-700 dark:text-emerald-400">
                      {t.coreFrontendEyebrow}
                    </div>
                    <h2 className="font-display text-2xl font-bold tracking-tight text-slate-900 dark:text-white mt-1">
                      {t.coreFrontendTitle}
                    </h2>
                  </div>
                  <button
                    type="button"
                    onClick={() => navigate('learn')}
                    className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 hover:underline inline-flex items-center gap-1"
                  >
                    <span>{t.openSandbox}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {basicThreeTracks.map((track) => {
                    const done = completedTracks.has(track.id);
                    return (
                      <button
                        key={track.id}
                        type="button"
                        onClick={() => handleOpenTrack(track.id)}
                        className="group text-left p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-emerald-500/60 transition-colors flex flex-col justify-between gap-5"
                      >
                        <div className="space-y-4">
                          <div className="h-36 w-full overflow-hidden rounded-lg">
                            <TrackIllustration trackId={track.id} />
                          </div>

                          <div>
                            <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                              <span>
                                {track.accentLabel} · {track.duration}
                              </span>
                              {done && (
                                <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400 font-medium">
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  <span>{t.done}</span>
                                </span>
                              )}
                            </div>

                            <h3 className="font-display text-xl font-bold text-slate-900 dark:text-white mt-1.5 group-hover:text-emerald-700 dark:group-hover:text-emerald-400 transition-colors">
                              {track.title}
                            </h3>
                            <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mt-0.5">
                              {track.amharicTitle}
                            </p>
                            <p className="text-sm text-slate-600 dark:text-slate-300 mt-2.5 leading-relaxed">
                              {track.subtitle}
                            </p>
                          </div>
                        </div>

                        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-slate-800 dark:text-slate-200">
                          <span>{t.openLesson}</span>
                          <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors" />
                        </div>
                      </button>
                    );
                  })}
                </div>
              </section>

              {/* Backend & Database Section */}
              <section className="space-y-6">
                <div>
                  <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
                    {t.backendEyebrow}
                  </div>
                  <h2 className="font-display text-2xl font-bold tracking-tight text-slate-900 dark:text-white mt-1">
                    {t.backendTitle}
                  </h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {backendTracks.map((track) => {
                    const done = completedTracks.has(track.id);
                    return (
                      <button
                        key={track.id}
                        type="button"
                        onClick={() => handleOpenTrack(track.id)}
                        className="group text-left p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-emerald-500/60 transition-colors grid grid-cols-1 sm:grid-cols-12 gap-5 items-center"
                      >
                        <div className="sm:col-span-5 h-32 overflow-hidden rounded-lg">
                          <TrackIllustration trackId={track.id} />
                        </div>
                        <div className="sm:col-span-7 space-y-2">
                          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                            <span>
                              {track.accentLabel} · {track.duration}
                            </span>
                            {done && (
                              <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400 font-medium">
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>{t.done}</span>
                              </span>
                            )}
                          </div>
                          <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white group-hover:text-emerald-700 dark:group-hover:text-emerald-400 transition-colors">
                            {track.title} — {track.amharicTitle}
                          </h3>
                          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                            {track.subtitle}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </section>
            </div>
          )}

          {(currentView === 'learn' || currentView === 'php' || currentView === 'mysql') && (
            <InteractiveSandbox
              language={language}
              t={t}
              activeTrackId={activeTrackId}
              onSelectTrack={handleOpenTrack}
              completedTracks={completedTracks}
              onToggleComplete={toggleTrackComplete}
            />
          )}

          {(currentView === 'about' || currentView === 'more-home') && (
            <AboutView language={language} t={t} onOpenTrack={handleOpenTrack} />
          )}

          {(currentView === 'login' || currentView === 'register') && (
            <AuthViews
              mode={currentView}
              t={t}
              onSwitchMode={(m) => navigate(m)}
              onSuccess={(name) => {
                setUserName(name);
                navigate('home');
              }}
              onCancel={() => navigate('home')}
            />
          )}
        </main>

        {/* Grounded Footer */}
        <footer className="mt-16 bg-slate-900 dark:bg-slate-900 border-t border-slate-800 text-slate-200 px-6 py-8">
          <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
            <div>
              <div className="font-display text-base font-bold text-white">
                {t.footerCompany}
              </div>
              <div className="text-xs text-slate-400 mt-1">{t.footerContact}</div>
            </div>
            <div className="text-xs text-slate-400">{t.footerCopyright}</div>
          </div>
        </footer>
      </div>
    </div>
  );
}
