export type FileCategory = 'code' | 'docs' | 'data' | 'media' | 'binary';

export type ViewMode = 'preview' | 'source' | 'split' | 'edit';

export interface WorkspaceFile {
  id: string;
  name: string;
  path: string;
  folder: string;
  extension: string;
  language: string;
  category: FileCategory;
  content: string;
  sizeBytes: number;
  updatedAt: string;
  encoding?: string;
  isUserAdded?: boolean;
  binaryUrl?: string;
  mimeType?: string;
}

export interface FolderNode {
  name: string;
  path: string;
  folders: FolderNode[];
  files: WorkspaceFile[];
}
