import { FileCategory, FolderNode, WorkspaceFile } from '../types/files';

export function getExtension(filename: string): string {
  const idx = filename.lastIndexOf('.');
  if (idx <= 0) return '';
  return filename.slice(idx + 1).toLowerCase();
}

export function detectLanguage(ext: string): {
  language: string;
  category: FileCategory;
} {
  switch (ext) {
    case 'php':
      return { language: 'PHP / HTML', category: 'code' };
    case 'html':
    case 'htm':
      return { language: 'HTML', category: 'code' };
    case 'ts':
    case 'tsx':
      return { language: 'TypeScript', category: 'code' };
    case 'js':
    case 'jsx':
    case 'mjs':
      return { language: 'JavaScript', category: 'code' };
    case 'css':
    case 'scss':
      return { language: 'CSS', category: 'code' };
    case 'py':
      return { language: 'Python', category: 'code' };
    case 'sql':
      return { language: 'SQL', category: 'code' };
    case 'sh':
    case 'bash':
      return { language: 'Shell', category: 'code' };
    case 'xml':
      return { language: 'XML', category: 'code' };
    case 'md':
    case 'markdown':
      return { language: 'Markdown', category: 'docs' };
    case 'txt':
    case 'log':
      return { language: 'Plain Text', category: 'docs' };
    case 'json':
      return { language: 'JSON', category: 'data' };
    case 'csv':
      return { language: 'CSV', category: 'data' };
    case 'yaml':
    case 'yml':
      return { language: 'YAML', category: 'data' };
    case 'svg':
      return { language: 'SVG Image', category: 'media' };
    case 'png':
    case 'jpg':
    case 'jpeg':
    case 'gif':
    case 'webp':
    case 'ico':
      return { language: 'Raster Image', category: 'media' };
    case 'pdf':
      return { language: 'PDF Document', category: 'media' };
    default:
      return { language: ext ? ext.toUpperCase() : 'Text', category: 'docs' };
  }
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function countLines(text: string): number {
  if (!text) return 0;
  return text.split(/\r?\n/).length;
}

export function isPreviewable(file: WorkspaceFile): boolean {
  const ext = file.extension;
  return (
    ext === 'php' ||
    ext === 'html' ||
    ext === 'htm' ||
    ext === 'md' ||
    ext === 'markdown' ||
    ext === 'csv' ||
    ext === 'json' ||
    ext === 'svg' ||
    file.category === 'media'
  );
}

export function buildFolderTree(files: WorkspaceFile[]): FolderNode {
  const root: FolderNode = {
    name: 'Workspace',
    path: '',
    folders: [],
    files: [],
  };

  const folderMap = new Map<string, FolderNode>();
  folderMap.set('', root);

  const ensureFolder = (folderPath: string): FolderNode => {
    if (!folderPath) return root;
    const existing = folderMap.get(folderPath);
    if (existing) return existing;

    const parts = folderPath.split('/').filter(Boolean);
    let currentPath = '';
    let parent = root;

    for (const part of parts) {
      currentPath = currentPath ? `${currentPath}/${part}` : part;
      let node = folderMap.get(currentPath);
      if (!node) {
        node = {
          name: part,
          path: currentPath,
          folders: [],
          files: [],
        };
        folderMap.set(currentPath, node);
        parent.folders.push(node);
      }
      parent = node;
    }
    return parent;
  };

  for (const file of files) {
    const parent = ensureFolder(file.folder);
    parent.files.push(file);
  }

  const sortTree = (node: FolderNode) => {
    node.folders.sort((a, b) => a.name.localeCompare(b.name));
    node.files.sort((a, b) => a.name.localeCompare(b.name));
    node.folders.forEach(sortTree);
  };
  sortTree(root);

  return root;
}

export function parseCsv(content: string): { headers: string[]; rows: string[][] } {
  const lines: string[][] = [];
  let currentRow: string[] = [];
  let currentVal = '';
  let inQuotes = false;

  for (let i = 0; i < content.length; i++) {
    const char = content[i];
    const next = content[i + 1];

    if (inQuotes) {
      if (char === '"' && next === '"') {
        currentVal += '"';
        i++;
      } else if (char === '"') {
        inQuotes = false;
      } else {
        currentVal += char;
      }
    } else {
      if (char === '"') {
        inQuotes = true;
      } else if (char === ',') {
        currentRow.push(currentVal.trim());
        currentVal = '';
      } else if (char === '\r' && next === '\n') {
        currentRow.push(currentVal.trim());
        if (currentRow.some((cell) => cell !== '')) lines.push(currentRow);
        currentRow = [];
        currentVal = '';
        i++;
      } else if (char === '\n' || char === '\r') {
        currentRow.push(currentVal.trim());
        if (currentRow.some((cell) => cell !== '')) lines.push(currentRow);
        currentRow = [];
        currentVal = '';
      } else {
        currentVal += char;
      }
    }
  }

  if (currentVal.length > 0 || currentRow.length > 0) {
    currentRow.push(currentVal.trim());
    if (currentRow.some((cell) => cell !== '')) lines.push(currentRow);
  }

  if (lines.length === 0) {
    return { headers: [], rows: [] };
  }

  const [headers, ...rows] = lines;
  return { headers, rows };
}

/**
 * Resolves simple PHP echo / template expressions for safe preview rendering
 * alongside HTML markup, without executing arbitrary server code.
 */
export function renderPhpTemplateToHtml(phpSource: string): string {
  const variables: Record<string, string> = {
    '$title': 'File Viewer — Learning & Inspection Guide',
    '$appTitle': 'File Viewer',
    '$rootDir': '/workspace',
    '$activeFrame': 'frame (learn.php)',
    '$leftFrame': 'leftFrame (file.php)',
    '$topFrame': 'topFrame (icon.php)',
    '$phpVersion': '8.3',
    '$encoding': 'UTF-8',
    '$date': new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }),
  };

  // Extract simple string variable assignments: $var = "value"; or 'value';
  const assignRegex = /(\$[a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*(['"])(.*?)\2\s*;/g;
  let match: RegExpExecArray | null;
  while ((match = assignRegex.exec(phpSource)) !== null) {
    variables[match[1]] = match[3];
  }

  // Replace <?= $var ?> or <?php echo $var; ?> and strip remaining <?php ... ?> blocks
  let html = phpSource.replace(/<\?(?:php|=)\s*([\s\S]*?)\?>/gi, (_full, inner: string) => {
    const trimmed = inner.trim();
    const echoMatch = trimmed.match(/^(?:echo\s+)?(\$[a-zA-Z_][a-zA-Z0-9_]*)\s*;?$/);
    if (echoMatch && variables[echoMatch[1]]) {
      return variables[echoMatch[1]];
    }
    const strEchoMatch = trimmed.match(/^(?:echo\s+)?(['"])([\s\S]*?)\1\s*;?$/);
    if (strEchoMatch) {
      return strEchoMatch[2];
    }
    if (trimmed.includes('date(')) {
      return variables['$date'];
    }
    return '';
  });

  // Strip any script tags for safety in preview
  html = html.replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, '');
  return html;
}

export async function readLocalFile(file: File, folder = 'uploads'): Promise<WorkspaceFile> {
  const ext = getExtension(file.name);
  const { language, category } = detectLanguage(ext);
  const relativePath = (file as File & { webkitRelativePath?: string }).webkitRelativePath;
  const derivedFolder = relativePath && relativePath.includes('/')
    ? `${folder}/${relativePath.slice(0, relativePath.lastIndexOf('/'))}`
    : folder;

  const isRasterOrPdf =
    ['png', 'jpg', 'jpeg', 'gif', 'webp', 'ico', 'pdf'].includes(ext) ||
    file.type.startsWith('image/') && ext !== 'svg' ||
    file.type === 'application/pdf';

  if (isRasterOrPdf) {
    const dataUrl = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result ?? ''));
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsDataURL(file);
    });

    return {
      id: `local-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      name: file.name,
      path: `${derivedFolder}/${file.name}`,
      folder: derivedFolder,
      extension: ext,
      language,
      category: 'media',
      content: '',
      sizeBytes: file.size,
      updatedAt: new Date(file.lastModified || Date.now()).toISOString().slice(0, 10),
      encoding: 'Binary',
      isUserAdded: true,
      binaryUrl: dataUrl,
      mimeType: file.type,
    };
  }

  const text = await file.text();
  return {
    id: `local-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    name: file.name,
    path: `${derivedFolder}/${file.name}`,
    folder: derivedFolder,
    extension: ext,
    language,
    category,
    content: text,
    sizeBytes: file.size,
    updatedAt: new Date(file.lastModified || Date.now()).toISOString().slice(0, 10),
    encoding: 'UTF-8',
    isUserAdded: true,
    mimeType: file.type || 'text/plain',
  };
}
