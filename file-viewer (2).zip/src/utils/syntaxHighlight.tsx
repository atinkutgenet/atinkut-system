import React from 'react';

type TokenType =
  | 'plain'
  | 'comment'
  | 'string'
  | 'keyword'
  | 'tag'
  | 'attr'
  | 'number'
  | 'variable'
  | 'punctuation';

interface Token {
  type: TokenType;
  value: string;
}

const CODE_KEYWORDS = new Set([
  'function', 'return', 'const', 'let', 'var', 'if', 'else', 'elseif', 'for',
  'foreach', 'while', 'switch', 'case', 'break', 'continue', 'default', 'export',
  'import', 'from', 'interface', 'type', 'class', 'extends', 'implements', 'new',
  'true', 'false', 'null', 'undefined', 'echo', 'print', 'include', 'require',
  'array', 'as', 'async', 'await', 'try', 'catch', 'throw', 'public', 'private',
  'protected', 'static', 'readonly', 'void', 'string', 'number', 'boolean', 'php',
]);

function tokenizeLine(line: string, ext: string): Token[] {
  if (!line) return [];
  const tokens: Token[] = [];
  let i = 0;

  const isMarkup = ext === 'html' || ext === 'htm' || ext === 'php' || ext === 'svg' || ext === 'xml';
  const isJson = ext === 'json';

  while (i < line.length) {
    // Comments // or # (for php/sh/py)
    if (
      (line[i] === '/' && line[i + 1] === '/') ||
      ((ext === 'php' || ext === 'py' || ext === 'sh') && line[i] === '#')
    ) {
      tokens.push({ type: 'comment', value: line.slice(i) });
      break;
    }

    // Block comment start /* or <!--
    if (line.slice(i, i + 2) === '/*' || line.slice(i, i + 4) === '<!--') {
      const endSeq = line.slice(i, i + 2) === '/*' ? '*/' : '-->';
      const endIdx = line.indexOf(endSeq, i + endSeq.length);
      if (endIdx !== -1) {
        tokens.push({ type: 'comment', value: line.slice(i, endIdx + endSeq.length) });
        i = endIdx + endSeq.length;
        continue;
      } else {
        tokens.push({ type: 'comment', value: line.slice(i) });
        break;
      }
    }

    // PHP open/close tags
    if (line.slice(i, i + 5) === '<?php' || line.slice(i, i + 3) === '<?=' || line.slice(i, i + 2) === '?>') {
      const tagLen = line.slice(i, i + 5) === '<?php' ? 5 : line.slice(i, i + 3) === '<?=' ? 3 : 2;
      tokens.push({ type: 'keyword', value: line.slice(i, i + tagLen) });
      i += tagLen;
      continue;
    }

    // Strings ("...", '...', `...`)
    if (line[i] === '"' || line[i] === "'" || line[i] === '`') {
      const quote = line[i];
      let j = i + 1;
      while (j < line.length) {
        if (line[j] === '\\') {
          j += 2;
          continue;
        }
        if (line[j] === quote) {
          j++;
          break;
        }
        j++;
      }
      const strVal = line.slice(i, j);
      // In JSON, check if followed by colon => key/attr
      const after = line.slice(j).trimStart();
      tokens.push({
        type: isJson && after.startsWith(':') ? 'attr' : 'string',
        value: strVal,
      });
      i = j;
      continue;
    }

    // PHP Variables ($var)
    if (line[i] === '$' && /[a-zA-Z_]/.test(line[i + 1] ?? '')) {
      let j = i + 1;
      while (j < line.length && /[a-zA-Z0-9_]/.test(line[j])) j++;
      tokens.push({ type: 'variable', value: line.slice(i, j) });
      i = j;
      continue;
    }

    // HTML/XML/SVG Tags (<tag, </tag)
    if (isMarkup && line[i] === '<' && /[a-zA-Z!/]/.test(line[i + 1] ?? '')) {
      let j = i + 1;
      if (line[j] === '/' || line[j] === '!') j++;
      while (j < line.length && /[a-zA-Z0-9:-]/.test(line[j])) j++;
      tokens.push({ type: 'tag', value: line.slice(i, j) });
      i = j;
      continue;
    }

    // Numbers
    if (/[0-9]/.test(line[i]) && (i === 0 || !/[a-zA-Z_]/.test(line[i - 1]))) {
      let j = i;
      while (j < line.length && /[0-9._xXa-fA-F]/.test(line[j])) j++;
      tokens.push({ type: 'number', value: line.slice(i, j) });
      i = j;
      continue;
    }

    // Identifiers & keywords
    if (/[a-zA-Z_]/.test(line[i])) {
      let j = i;
      while (j < line.length && /[a-zA-Z0-9_-]/.test(line[j])) j++;
      const word = line.slice(i, j);
      if (CODE_KEYWORDS.has(word)) {
        tokens.push({ type: 'keyword', value: word });
      } else if (isMarkup && line.slice(j).trimStart().startsWith('=')) {
        tokens.push({ type: 'attr', value: word });
      } else {
        tokens.push({ type: 'plain', value: word });
      }
      i = j;
      continue;
    }

    // Punctuation
    if (/[{}()[\].,:;=<>/+\-*&|!?]/.test(line[i])) {
      tokens.push({ type: 'punctuation', value: line[i] });
      i++;
      continue;
    }

    // Whitespace or other characters
    let j = i + 1;
    while (
      j < line.length &&
      !/[a-zA-Z0-9_$"'`<{}\[\]().,:;=<>/+\-*&|!?#]/.test(line[j])
    ) {
      j++;
    }
    tokens.push({ type: 'plain', value: line.slice(i, j) });
    i = j;
  }

  return tokens;
}

const TOKEN_CLASSES: Record<TokenType, string> = {
  plain: 'text-slate-800 dark:text-slate-200',
  comment: 'text-slate-400 dark:text-slate-500 italic',
  string: 'text-emerald-700 dark:text-emerald-400',
  keyword: 'text-blue-700 dark:text-sky-400 font-medium',
  tag: 'text-indigo-700 dark:text-indigo-400 font-medium',
  attr: 'text-amber-700 dark:text-amber-300',
  number: 'text-orange-700 dark:text-orange-300',
  variable: 'text-cyan-700 dark:text-cyan-300',
  punctuation: 'text-slate-500 dark:text-slate-400',
};

function highlightSearchInText(text: string, query: string): React.ReactNode {
  if (!query) return text;
  const lowerText = text.toLowerCase();
  const lowerQuery = query.toLowerCase();
  const parts: React.ReactNode[] = [];
  let start = 0;
  let idx = lowerText.indexOf(lowerQuery, start);

  while (idx !== -1) {
    if (idx > start) parts.push(text.slice(start, idx));
    parts.push(
      <mark
        key={idx}
        className="bg-amber-200/90 dark:bg-amber-500/40 text-slate-900 dark:text-white rounded-xs px-0.5"
      >
        {text.slice(idx, idx + query.length)}
      </mark>
    );
    start = idx + query.length;
    idx = lowerText.indexOf(lowerQuery, start);
  }
  if (start < text.length) parts.push(text.slice(start));
  return parts;
}

interface CodeViewerProps {
  content: string;
  extension: string;
  wrapLines: boolean;
  searchQuery?: string;
}

export const CodeViewer: React.FC<CodeViewerProps> = ({
  content,
  extension,
  wrapLines,
  searchQuery = '',
}) => {
  const lines = React.useMemo(() => content.split(/\r?\n/), [content]);

  return (
    <div className="font-mono text-[13px] leading-[1.65] bg-white dark:bg-slate-950 min-h-full py-3 select-text">
      <table className="w-full border-collapse">
        <tbody>
          {lines.map((line, idx) => {
            const tokens = tokenizeLine(line, extension);
            const hasMatch =
              searchQuery.length > 0 &&
              line.toLowerCase().includes(searchQuery.toLowerCase());

            return (
              <tr
                key={idx}
                className={
                  hasMatch
                    ? 'bg-amber-50/70 dark:bg-amber-950/25'
                    : 'hover:bg-slate-50 dark:hover:bg-slate-900/60'
                }
              >
                <td
                  aria-hidden="true"
                  className="select-none text-right pr-4 pl-4 text-[12px] text-slate-400 dark:text-slate-600 tabular-nums align-top w-12 shrink-0 border-r border-slate-100 dark:border-slate-900"
                >
                  {idx + 1}
                </td>
                <td
                  className={`pl-4 pr-6 align-top ${
                    wrapLines ? 'whitespace-pre-wrap break-all' : 'whitespace-pre'
                  }`}
                >
                  {tokens.length === 0 ? (
                    <span>&nbsp;</span>
                  ) : (
                    tokens.map((tok, tIdx) => (
                      <span key={tIdx} className={TOKEN_CLASSES[tok.type]}>
                        {highlightSearchInText(tok.value, searchQuery)}
                      </span>
                    ))
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
