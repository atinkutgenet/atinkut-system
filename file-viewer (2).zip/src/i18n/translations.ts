export type Language = 'am' | 'en' | 'om';

export interface LanguageOption {
  code: Language;
  label: string;
  shortLabel: string;
}

export const LANGUAGE_OPTIONS: LanguageOption[] = [
  { code: 'am', label: 'አማርኛ', shortLabel: 'አማ' },
  { code: 'en', label: 'English', shortLabel: 'EN' },
  { code: 'om', label: 'Afaan Oromoo', shortLabel: 'OM' },
];

export interface TranslationStrings {
  brand: string;
  companyName: string;
  menuButton: string;
  menuTitle: string;
  closeMenu: string;
  languageLabel: string;
  navHome: string;
  navHomeSub: string;
  navLearnClass: string;
  navLearnClassSub: string;
  navMoreHome: string;
  navMoreHomeSub: string;
  navRegister: string;
  navRegisterSub: string;
  navPhpSub: string;
  navMysqlSub: string;
  navAbout: string;
  navAboutSub: string;
  back: string;
  login: string;
  logout: string;
  switchToLight: string;
  switchToDark: string;
  drawerFooter: string;
  lessonsCompletedOf: (done: number, total: number) => string;
  greetingSignedIn: (name: string) => string;
  greetingGuest: string;
  heroTitle: string;
  heroSubtitle: string;
  startLearnClass: string;
  exploreCurriculum: string;
  showcaseItems: [
    { kicker: string; title: string; desc: string },
    { kicker: string; title: string; desc: string },
    { kicker: string; title: string; desc: string },
  ];
  coreFrontendEyebrow: string;
  coreFrontendTitle: string;
  openSandbox: string;
  openLesson: string;
  done: string;
  backendEyebrow: string;
  backendTitle: string;
  lessonCompleted: string;
  markComplete: string;
  sqlEditor: string;
  codeEditor: string;
  reset: string;
  copy: string;
  copied: string;
  run: string;
  queryResultTable: string;
  liveOutputPreview: string;
  rowsCount: (n: number) => string;
  sandboxed: string;
  queryNotice: string;
  allRows: string;
  completedOnly: string;
  learningGoalPrefix: (num: string) => string;
  sqlOnlySelect: string;
  sqlFromHint: string;
  sqlNoValidCols: string;
  sqlBadWhere: string;
  sqlUnknownCol: (field: string) => string;
  signInTitle: string;
  registerTitle: string;
  signInSubtitle: string;
  registerSubtitle: string;
  fullName: string;
  fullNamePlaceholder: string;
  emailAddress: string;
  password: string;
  passwordPlaceholder: string;
  missingCreds: string;
  cancel: string;
  signInBtn: string;
  completeRegBtn: string;
  newHere: string;
  alreadyEnrolled: string;
  registerHere: string;
  signInHere: string;
  aboutEyebrow: string;
  aboutTitle: string;
  aboutDesc: string;
  statTracksTitle: string;
  statTracksDesc: string;
  statLangTitle: string;
  statLangDesc: string;
  statLabsTitle: string;
  statLabsDesc: string;
  exploreAllTracks: string;
  footerCompany: string;
  footerContact: string;
  footerCopyright: string;
}

export const TRANSLATIONS: Record<Language, TranslationStrings> = {
  am: {
    brand: 'የአትንኩት ድረ-ገጽ',
    companyName: 'አትንኩት ቴክኖሎጂ',
    menuButton: 'ዝርዝር (ሜኑ)',
    menuTitle: 'ዝርዝር (ሜኑ)',
    closeMenu: 'ሜኑውን ዝጋ',
    languageLabel: 'ቋንቋ',
    navHome: 'ዋና ገጽ',
    navHomeSub: 'አጠቃላይ እይታ',
    navLearnClass: 'መማሪያ ክፍል',
    navLearnClassSub: 'HTML፣ CSS እና JavaScript',
    navMoreHome: 'ተጨማሪ ገጽ',
    navMoreHomeSub: 'ሙሉ የትምህርት ካርታ',
    navRegister: 'መመዝገቢያ',
    navRegisterSub: 'የተማሪ ምዝገባ',
    navPhpSub: 'የሰርቨር ቴምፕሌቶች እና ሎጂክ',
    navMysqlSub: 'የውሂብ ጎታ ጥያቄዎች እና ሰንጠረዦች',
    navAbout: 'ስለ እኛ',
    navAboutSub: 'አትንኩት ቴክኖሎጂ',
    back: 'ተመለስ',
    login: 'ግባ',
    logout: 'ውጣ',
    switchToLight: 'ወደ ብርሃን ገጽታ ቀይር',
    switchToDark: 'ወደ ጨለማ ገጽታ ቀይር',
    drawerFooter: 'አትንኩት ቴክኖሎጂ · የድረ-ገጽ መማሪያ',
    lessonsCompletedOf: (done, total) => `${done} ከ ${total} ትምህርቶች ተጠናቀዋል`,
    greetingSignedIn: (name) => `ሰላም ${name}`,
    greetingGuest: 'እንኳን ደህና መጡ',
    heroTitle: 'ወደ አትንኩት ድረ-ገጽ እንኳን በደህና መጡ።',
    heroSubtitle:
      'መሰረታዊ የድረ-ገጽ ልማት ትምህርት — HTML5፣ CSS3፣ JavaScript፣ PHP እና MySQLን በቀጥታ እየተለማመዱ ይማሩ።',
    startLearnClass: 'መማሪያ ክፍል ጀምር',
    exploreCurriculum: 'ሙሉ ትምህርቶችን ይመልከቱ',
    showcaseItems: [
      {
        kicker: '01. አወቃቀር',
        title: 'መሰረታዊ የድረ-ገጽ አወቃቀር',
        desc: 'ርዕሶች፣ ሜኑዎች እና የተደራጁ ገጾች',
      },
      {
        kicker: '02. አቀራረብ',
        title: 'Flexbox እና ጨለማ/ብርሃን ገጽታ',
        desc: 'ንጹህ ክፍተት፣ ቅርጸ-ቁምፊ እና ቀለሞች',
      },
      {
        kicker: '03. ተግባራዊነት',
        title: 'የJavaScript እንቅስቃሴ እና ሜኑዎች',
        desc: 'የቀጥታ መቀያየሪያዎች እና ክስተቶች',
      },
    ],
    coreFrontendEyebrow: 'መሰረታዊ የፊት-ገጽ ትምህርቶች',
    coreFrontendTitle: 'መሰረታዊ የድረ-ገጽ ልማት ትምህርቶች',
    openSandbox: 'የቀጥታ መለማመጃ ክፍል ክፈት',
    openLesson: 'ትምህርቱን ክፈት',
    done: 'ተጠናቋል',
    backendEyebrow: 'የሰርቨር እና የውሂብ ጎታ ምህንድስና',
    backendTitle: 'የPHP እና MySQL ትምህርቶች',
    lessonCompleted: 'ትምህርቱ ተጠናቋል',
    markComplete: 'ተጠናቋል በል',
    sqlEditor: 'የSQL መጠይቅ መጻፊያ',
    codeEditor: 'የቀጥታ ኮድ መጻፊያ',
    reset: 'ዳግም አስጀምር',
    copy: 'ቅዳ',
    copied: 'ተቀድቷል',
    run: 'አሂድ',
    queryResultTable: 'የመጠይቅ ውጤት ሰንጠረዥ',
    liveOutputPreview: 'የቀጥታ ውጤት እይታ',
    rowsCount: (n) => `${n} ረድፎች`,
    sandboxed: 'የተጠበቀ እይታ',
    queryNotice: 'የመጠይቅ ማሳሰቢያ',
    allRows: 'ሁሉንም አሳይ',
    completedOnly: 'የተጠናቀቁ ብቻ',
    learningGoalPrefix: (num) => `${num}. የትምህርት ግብ`,
    sqlOnlySelect: 'በዚህ የMySQL መለማመጃ ውስጥ የSELECT መጠይቆች ብቻ ይደገፋሉ።',
    sqlFromHint:
      'ከ enrollments ሰንጠረዥ ይጠይቁ፤ ለምሳሌ፡ SELECT id, student_name, track, progress_pct FROM enrollments WHERE progress_pct >= 60 ORDER BY progress_pct DESC;',
    sqlNoValidCols: 'ትክክለኛ ዓምዶች አልተመረጡም። የሚገኙ ዓምዶች፡ ',
    sqlBadWhere:
      "የWHERE ሁኔታ ትክክል አይደለም። ምሳሌ፡ WHERE progress_pct >= 75 ወይም WHERE status = 'Active'",
    sqlUnknownCol: (field) => `በWHERE ውስጥ "${field}" የሚባል ዓምድ አልተገኘም።`,
    signInTitle: 'የተማሪ መግቢያ',
    registerTitle: 'አዲስ መለያ ይፍጠሩ (መመዝገቢያ)',
    signInSubtitle: 'የድረ-ገጽ ትምህርቶችዎን ሂደት ለመከታተል ይግቡ።',
    registerSubtitle: 'በአትንኩት ቴክኖሎጂ የድረ-ገጽ ትምህርቶች ለመሳተፍ ይመዝገቡ።',
    fullName: 'ሙሉ ስም',
    fullNamePlaceholder: 'ለምሳሌ፡ አትንኩት ገነት',
    emailAddress: 'ኢሜይል አድራሻ',
    password: 'የይለፍ ቃል',
    passwordPlaceholder: 'የይለፍ ቃል ያስገቡ',
    missingCreds: 'እባክዎ ኢሜይል እና የይለፍ ቃል ያስገቡ።',
    cancel: 'ሰርዝ',
    signInBtn: 'ግባ',
    completeRegBtn: 'ምዝገባውን አጠናቅቅ',
    newHere: 'አዲስ ተማሪ ነዎት?',
    alreadyEnrolled: 'ከዚህ በፊት ተመዝግበዋል?',
    registerHere: 'እዚህ ይመዝገቡ',
    signInHere: 'ይግቡ',
    aboutEyebrow: 'ስለ እኛ · አትንኩት ቴክኖሎጂ',
    aboutTitle: 'አትንኩት ቴክኖሎጂ — በአማርኛ የተዘጋጀ ተግባራዊ የድረ-ገጽ ልማት ትምህርት',
    aboutDesc:
      'የአትንኩት ድረ-ገጽ ተማሪዎች HTML5፣ CSS3፣ JavaScript፣ PHP እና MySQLን በቀላል ማብራሪያ እና በቀጥታ የመለማመጃ መድረክ በተግባር እንዲማሩ ያስችላል።',
    statTracksTitle: '5 ትምህርቶች',
    statTracksDesc: 'የፊት ገጽ አወቃቀር፣ ውበት፣ ሎጂክ፣ PHP ቴምፕሌቶች እና የMySQL መጠይቆች።',
    statLangTitle: 'ብዙ ቋንቋዎች',
    statLangDesc: 'አማርኛ፣ እንግሊዝኛ እና አፋን ኦሮሞን በቀጥታ መቀያየር ይችላሉ።',
    statLabsTitle: 'የቀጥታ መለማመጃ',
    statLabsDesc: 'HTML፣ CSS፣ JavaScript፣ PHP እና SQLን በቀጥታ በአሳሹ ውስጥ እየጻፉ ውጤቱን ይመልከቱ።',
    exploreAllTracks: 'ሁሉንም አምስት ትምህርቶች ይመልከቱ',
    footerCompany: 'አትንኩት ቴክኖሎጂ (Atinkut Technology)',
    footerContact: 'ኢሜይል: atinkut@example.com · ስልክ: +251 9XX XXX XXX',
    footerCopyright: '© 2026 አትንኩት ድረ-ገጽ። መብቱ በህግ የተጠበቀ ነው።',
  },
  en: {
    brand: 'Atinkut Web',
    companyName: 'Atinkut Technology',
    menuButton: 'Menu',
    menuTitle: 'Menu',
    closeMenu: 'Close menu',
    languageLabel: 'Language',
    navHome: 'Home',
    navHomeSub: 'Overview',
    navLearnClass: 'Learn Class',
    navLearnClassSub: 'HTML, CSS & JavaScript',
    navMoreHome: 'Curriculum',
    navMoreHomeSub: 'Full Learning Roadmap',
    navRegister: 'Register',
    navRegisterSub: 'Student Enrollment',
    navPhpSub: 'Server Templates & Logic',
    navMysqlSub: 'SQL Queries & Tables',
    navAbout: 'About',
    navAboutSub: 'Atinkut Technology',
    back: 'Back',
    login: 'Login',
    logout: 'Logout',
    switchToLight: 'Switch to light mode',
    switchToDark: 'Switch to dark mode',
    drawerFooter: 'Atinkut Technology · Web Lab',
    lessonsCompletedOf: (done, total) => `${done} of ${total} lessons completed`,
    greetingSignedIn: (name) => `Hi, ${name}`,
    greetingGuest: 'Welcome, Guest',
    heroTitle: 'Welcome to Atinkut Web Learning Portal.',
    heroSubtitle:
      'Basic learn in web development — Master HTML5, CSS3, JavaScript, PHP, and MySQL with interactive hands-on labs.',
    startLearnClass: 'Start Learn Class',
    exploreCurriculum: 'Explore Full Curriculum',
    showcaseItems: [
      {
        kicker: '01. Structure',
        title: 'Semantic Web Markup',
        desc: 'Headings, menus, and accessible pages',
      },
      {
        kicker: '02. Presentation',
        title: 'Responsive Flexbox & Dark Mode',
        desc: 'Clean spacing, typography, and themes',
      },
      {
        kicker: '03. Interactivity',
        title: 'JavaScript DOM & Menus',
        desc: 'Dynamic class toggles and live events',
      },
    ],
    coreFrontendEyebrow: 'Core Frontend Foundations',
    coreFrontendTitle: 'Basic Learn in Web Development',
    openSandbox: 'Open Interactive Sandbox',
    openLesson: 'Open Lesson',
    done: 'Done',
    backendEyebrow: 'Server & Database Engineering',
    backendTitle: 'PHP & MySQL Tracks',
    lessonCompleted: 'Lesson Completed',
    markComplete: 'Mark Complete',
    sqlEditor: 'SQL Query Editor',
    codeEditor: 'Live Code Editor',
    reset: 'Reset',
    copy: 'Copy',
    copied: 'Copied',
    run: 'Run',
    queryResultTable: 'Query Result Table',
    liveOutputPreview: 'Live Output Preview',
    rowsCount: (n) => `${n} rows`,
    sandboxed: 'Sandboxed',
    queryNotice: 'Query Notice',
    allRows: 'All rows',
    completedOnly: 'Completed only',
    learningGoalPrefix: (num) => `${num}. Learning Goal`,
    sqlOnlySelect: 'Only SELECT queries are supported in this client-side MySQL sandbox.',
    sqlFromHint:
      'Try querying FROM enrollments, e.g. SELECT id, student_name, track, progress_pct FROM enrollments WHERE progress_pct >= 60 ORDER BY progress_pct DESC;',
    sqlNoValidCols: 'No valid columns selected. Available columns: ',
    sqlBadWhere:
      "Unsupported WHERE condition. Example: WHERE progress_pct >= 75 or WHERE status = 'Active'",
    sqlUnknownCol: (field) => `Unknown column "${field}" in WHERE clause.`,
    signInTitle: 'Student Sign In',
    registerTitle: 'Create Account (Register)',
    signInSubtitle: 'Sign in to track your web development lessons.',
    registerSubtitle: 'Register for Atinkut Technology web development classes.',
    fullName: 'Full Name',
    fullNamePlaceholder: 'e.g. Atinkut Genet',
    emailAddress: 'Email Address',
    password: 'Password',
    passwordPlaceholder: 'Enter password',
    missingCreds: 'Please enter your email and password.',
    cancel: 'Cancel',
    signInBtn: 'Sign In',
    completeRegBtn: 'Complete Registration',
    newHere: 'New to Atinkut Tech?',
    alreadyEnrolled: 'Already enrolled?',
    registerHere: 'Register here',
    signInHere: 'Sign in',
    aboutEyebrow: 'About · Atinkut Technology',
    aboutTitle: 'Atinkut Technology — Practical Multilingual Web Development Education',
    aboutDesc:
      'Atinkut Web equips students with hands-on skills across HTML5, CSS3, JavaScript, PHP, and MySQL—combining clear multilingual guidance with interactive browser coding labs.',
    statTracksTitle: '5 Tracks',
    statTracksDesc: 'Frontend markup, styling, client logic, PHP templates, and MySQL queries.',
    statLangTitle: 'Multilingual',
    statLangDesc: 'Switch seamlessly between Amharic, English, and Afaan Oromoo.',
    statLabsTitle: 'Live Browser Labs',
    statLabsDesc: 'Edit HTML, CSS, JavaScript, PHP, and SQL directly and see results immediately.',
    exploreAllTracks: 'Explore All Five Tracks',
    footerCompany: 'Atinkut Technology (አትንኩት ቴክኖሎጂ)',
    footerContact: 'Email: atinkut@example.com · Phone: +251 9XX XXX XXX',
    footerCopyright: '© 2026 Atinkut Web. All rights reserved.',
  },
  om: {
    brand: 'Marsariitii Atinkut',
    companyName: 'Teknooloojii Atinkut',
    menuButton: 'Tarree (Menu)',
    menuTitle: 'Tarree (Menu)',
    closeMenu: 'Tarree cufi',
    languageLabel: 'Afaan',
    navHome: 'Fuula Duraa',
    navHomeSub: 'Ilaalcha Waliigalaa',
    navLearnClass: 'Kutaa Barnootaa',
    navLearnClassSub: 'HTML, CSS fi JavaScript',
    navMoreHome: 'Kaarikulamii',
    navMoreHomeSub: 'Karoora Barnootaa Guutuu',
    navRegister: 'Galmee',
    navRegisterSub: 'Galmee Barattootaa',
    navPhpSub: 'Tempileetii Sarvarii fi Loojikii',
    navMysqlSub: 'Gaaffilee SQL fi Gabateewwan',
    navAbout: "Waa'ee Keenya",
    navAboutSub: 'Teknooloojii Atinkut',
    back: 'Deebi’i',
    login: 'Seeni',
    logout: 'Ba’i',
    switchToLight: 'Gara bifa ifaatti jijjiiri',
    switchToDark: 'Gara bifa dukkanaatti jijjiiri',
    drawerFooter: 'Teknooloojii Atinkut · Mana Yaalii Weebii',
    lessonsCompletedOf: (done, total) => `Barnoota ${total} keessaa ${done} xumurameera`,
    greetingSignedIn: (name) => `Akkam ${name}`,
    greetingGuest: 'Baga Nagaan Dhuftan',
    heroTitle: 'Gara Marsariitii Atinkut Baga Nagaan Dhuftan.',
    heroSubtitle:
      'Barnoota bu’uuraa misooma weebii — HTML5, CSS3, JavaScript, PHP fi MySQL shaakala kallattiitiin baradhaa.',
    startLearnClass: 'Kutaa Barnootaa Jalqabi',
    exploreCurriculum: 'Barnoota Guutuu Ilaali',
    showcaseItems: [
      {
        kicker: '01. Caasaa',
        title: 'Caasaa Bu’uuraa Marsariitii',
        desc: 'Mata-duree, tarreewwan fi fuulota qindaa’oo',
      },
      {
        kicker: '02. Dhiyeessii',
        title: 'Flexbox fi Bifa Ifaa/Dukkanaa',
        desc: 'Qulqullina qindaa’inaa fi halluuwwan',
      },
      {
        kicker: '03. Gocha',
        title: 'Sochii JavaScript fi Tarreewwan',
        desc: 'Jijjiirama kallattii fi taateewwan',
      },
    ],
    coreFrontendEyebrow: 'Bu’uura Fuula Duraa',
    coreFrontendTitle: 'Barnoota Bu’uuraa Misooma Weebii',
    openSandbox: 'Mana Yaalii Kallattii Bani',
    openLesson: 'Barnoota Bani',
    done: 'Xumurame',
    backendEyebrow: 'Sarvarii fi Kuusaa Deetaa',
    backendTitle: 'Barnoota PHP fi MySQL',
    lessonCompleted: 'Barnoonni Xumurameera',
    markComplete: 'Xumurame Jedhi',
    sqlEditor: 'Barreessaa Gaaffii SQL',
    codeEditor: 'Barreessaa Koodii Kallattii',
    reset: 'Irra Deebi’i',
    copy: 'Garagalchi',
    copied: 'Garagalchameera',
    run: 'Hojjechiisi',
    queryResultTable: 'Gabatee Bu’aa Gaaffii',
    liveOutputPreview: 'Mul’ata Bu’aa Kallattii',
    rowsCount: (n) => `Tarree ${n}`,
    sandboxed: 'Daangeffame',
    queryNotice: 'Hubachiisa Gaaffii',
    allRows: 'Hunda agarsiisi',
    completedOnly: 'Kan xumuraman qofa',
    learningGoalPrefix: (num) => `${num}. Galma Barnootaa`,
    sqlOnlySelect: 'Mana yaalii MySQL kana keessatti gaaffilee SELECT qofatu deeggarama.',
    sqlFromHint:
      'Gabatee enrollments irraa gaafadhu, fakkeenyaaf: SELECT id, student_name, track, progress_pct FROM enrollments WHERE progress_pct >= 60 ORDER BY progress_pct DESC;',
    sqlNoValidCols: 'Utubaawwan sirriin hin filatamne. Utubaawwan jiran: ',
    sqlBadWhere:
      "Haalli WHERE sirrii miti. Fakkeenya: WHERE progress_pct >= 75 ykn WHERE status = 'Active'",
    sqlUnknownCol: (field) => `WHERE keessatti utubaan "${field}" hin argamne.`,
    signInTitle: 'Seensa Barataa',
    registerTitle: 'Herrega Haaraa Uumi (Galmee)',
    signInSubtitle: 'Adeemsa barnoota keessanii hordofuuf seenaa.',
    registerSubtitle: 'Barnoota misooma weebii Teknooloojii Atinkut irratti galmaa’aa.',
    fullName: 'Maqaa Guutuu',
    fullNamePlaceholder: 'Fkn. Atinkut Genet',
    emailAddress: 'Teessoo Iimeeyilii',
    password: 'Jecha Darbii',
    passwordPlaceholder: 'Jecha darbii galchi',
    missingCreds: 'Maaloo iimeeyilii fi jecha darbii galchaa.',
    cancel: 'Haqi',
    signInBtn: 'Seeni',
    completeRegBtn: 'Galmee Xumuri',
    newHere: 'Barataa haaraa dhaa?',
    alreadyEnrolled: 'Kanaan dura galmooftanii jirtuu?',
    registerHere: 'Asitti galmaa’aa',
    signInHere: 'Seenaa',
    aboutEyebrow: "Waa'ee Keenya · Teknooloojii Atinkut",
    aboutTitle: 'Teknooloojii Atinkut — Barnoota Misooma Weebii Afaanota Hedduutiin',
    aboutDesc:
      'Marsariitiin Atinkut barattoonni HTML5, CSS3, JavaScript, PHP fi MySQL ibsa ifa ta’ee fi mana yaalii kallattii biraawuzarii keessatti shaakalaan akka baratan gargaara.',
    statTracksTitle: 'Barnoota 5',
    statTracksDesc: 'Caasaa fuula duraa, miidhagina, loojikii, PHP fi gaaffilee MySQL.',
    statLangTitle: 'Afaanota 3',
    statLangDesc: 'Afaan Amaaraa, Ingilizii fi Afaan Oromoo gidduutti salphaatti jijjiiraa.',
    statLabsTitle: 'Shaakala Kallattii',
    statLabsDesc: 'HTML, CSS, JavaScript, PHP fi SQL kallattiin barreessaa bu’aa isaa ilaalaa.',
    exploreAllTracks: 'Barnoota Shanan Hunda Ilaali',
    footerCompany: 'Teknooloojii Atinkut (አትንኩት ቴክኖሎጂ)',
    footerContact: 'Iimeeyilii: atinkut@example.com · Bilbila: +251 9XX XXX XXX',
    footerCopyright: '© 2026 Marsariitii Atinkut. Mirgi hundi seeraan eegamaa dha.',
  },
};
