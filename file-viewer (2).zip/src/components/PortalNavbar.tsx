import React from 'react';
import { ArrowLeft, Globe, LogIn, LogOut, Menu, Moon, Sun, X } from 'lucide-react';
import {
  LANGUAGE_OPTIONS,
  Language,
  TranslationStrings,
} from '../i18n/translations';

export type PageView =
  | 'home'
  | 'learn'
  | 'more-home'
  | 'php'
  | 'mysql'
  | 'about'
  | 'login'
  | 'register';

interface PortalNavbarProps {
  currentView: PageView;
  menuOpen: boolean;
  canGoBack: boolean;
  isDark: boolean;
  userName: string | null;
  language: Language;
  t: TranslationStrings;
  onChangeLanguage: (lang: Language) => void;
  onToggleMenu: () => void;
  onNavigate: (view: PageView) => void;
  onBack: () => void;
  onToggleTheme: () => void;
  onLogout: () => void;
}

export const PortalNavbar: React.FC<PortalNavbarProps> = ({
  currentView,
  menuOpen,
  canGoBack,
  isDark,
  userName,
  language,
  t,
  onChangeLanguage,
  onToggleMenu,
  onNavigate,
  onBack,
  onToggleTheme,
  onLogout,
}) => {
  const navItems: { id: PageView; label: string }[] = [
    { id: 'home', label: t.navHome },
    { id: 'learn', label: t.navLearnClass },
    { id: 'php', label: 'PHP' },
    { id: 'mysql', label: 'MySQL' },
    { id: 'about', label: t.navAbout },
  ];

  return (
    <header className="sticky top-0 z-40 h-16 px-4 md:px-6 flex items-center justify-between gap-4 md:gap-6 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs border-b border-slate-200 dark:border-slate-800">
      {/* Zone 1: Menu Drawer Button + Brand Wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          type="button"
          onClick={onToggleMenu}
          aria-expanded={menuOpen}
          aria-label={t.menuButton}
          className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0"
        >
          {menuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          <span>{t.menuButton}</span>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('home')}
          className="font-display text-base md:text-lg font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0 text-left"
        >
          {t.brand}
        </button>
      </div>

      {/* Zone 2: 5 Clean Single-Line Nav Links */}
      <nav className="hidden lg:flex items-center gap-6 text-sm font-medium">
        {navItems.map((item) => {
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(item.id)}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                isActive
                  ? 'border-emerald-600 text-slate-950 dark:text-white dark:border-emerald-400'
                  : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:border-slate-300 dark:hover:border-slate-600'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: Back, Language Selector, Theme Toggle, and Login/Logout */}
      <div className="flex items-center gap-2 shrink-0">
        {canGoBack && (
          <button
            type="button"
            onClick={onBack}
            title={t.back}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>{t.back}</span>
          </button>
        )}

        {/* Language Switcher */}
        <label className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors shrink-0 cursor-pointer">
          <Globe className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400 shrink-0" />
          <span className="sr-only">{t.languageLabel}</span>
          <select
            aria-label={t.languageLabel}
            value={language}
            onChange={(e) => onChangeLanguage(e.target.value as Language)}
            className="bg-transparent text-xs font-semibold text-slate-800 dark:text-slate-100 focus:outline-none cursor-pointer"
          >
            {LANGUAGE_OPTIONS.map((opt) => (
              <option
                key={opt.code}
                value={opt.code}
                className="bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100"
              >
                {opt.label}
              </option>
            ))}
          </select>
        </label>

        <button
          type="button"
          onClick={onToggleTheme}
          aria-label={isDark ? t.switchToLight : t.switchToDark}
          title={isDark ? t.switchToLight : t.switchToDark}
          className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
        >
          {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>

        {userName ? (
          <button
            type="button"
            onClick={onLogout}
            className="px-3.5 py-2 rounded-lg text-xs font-semibold text-slate-900 dark:text-slate-100 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">
              {t.logout} ({userName})
            </span>
            <span className="sm:hidden">{t.logout}</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => onNavigate('login')}
            className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 dark:bg-emerald-600 dark:hover:bg-emerald-500 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>{t.login}</span>
          </button>
        )}
      </div>
    </header>
  );
};
