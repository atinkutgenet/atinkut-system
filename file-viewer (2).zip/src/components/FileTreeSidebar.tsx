import React, { useMemo, useState } from 'react';
import {
  ChevronDown,
  ChevronRight,
  FileCode2,
  FileImage,
  FileSpreadsheet,
  FileText,
  Folder,
  FolderOpen,
  Trash2,
  Upload,
} from 'lucide-react';
import { FileCategory, FolderNode, WorkspaceFile } from '../types/files';
import { buildFolderTree, formatBytes } from '../utils/fileHelpers';

interface FileTreeSidebarProps {
  files: WorkspaceFile[];
  activeFileId: string | null;
  searchQuery: string;
  onClearSearch: () => void;
  onSelectFile: (fileId: string) => void;
  onDeleteFile: (fileId: string) => void;
  onDropFiles: (files: FileList) => void;
}

function getFileIcon(file: WorkspaceFile) {
  switch (file.category) {
    case 'code':
      return <FileCode2 className="w-4 h-4 text-blue-600 dark:text-sky-400 shrink-0" />;
    case 'data':
      return <FileSpreadsheet className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />;
    case 'media':
      return <FileImage className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />;
    default:
      return <FileText className="w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" />;
  }
}

function highlightMatch(text: string, query: string): React.ReactNode {
  const q = query.trim();
  if (!q) return text;
  const idx = text.toLowerCase().indexOf(q.toLowerCase());
  if (idx === -1) return text;
  return (
    <>
      {text.slice(0, idx)}
      <mark className="bg-amber-200/90 dark:bg-amber-500/35 text-slate-900 dark:text-white rounded-xs px-0.5">
        {text.slice(idx, idx + q.length)}
      </mark>
      {text.slice(idx + q.length)}
    </>
  );
}

export const FileTreeSidebar: React.FC<FileTreeSidebarProps> = ({
  files,
  activeFileId,
  searchQuery,
  onClearSearch,
  onSelectFile,
  onDeleteFile,
  onDropFiles,
}) => {
  const [categoryFilter, setCategoryFilter] = useState<'all' | FileCategory>('all');
  const [collapsedFolders, setCollapsedFolders] = useState<Set<string>>(new Set());
  const [isDragOver, setIsDragOver] = useState(false);

  const trimmedQuery = searchQuery.trim().toLowerCase();

  const filteredFiles = useMemo(() => {
    return files.filter((f) => {
      if (categoryFilter !== 'all' && f.category !== categoryFilter) return false;
      if (!trimmedQuery) return true;
      return (
        f.name.toLowerCase().includes(trimmedQuery) ||
        f.path.toLowerCase().includes(trimmedQuery) ||
        f.language.toLowerCase().includes(trimmedQuery) ||
        f.extension.toLowerCase().includes(trimmedQuery)
      );
    });
  }, [files, trimmedQuery, categoryFilter]);

  const tree = useMemo(() => buildFolderTree(filteredFiles), [filteredFiles]);

  const toggleFolder = (path: string) => {
    setCollapsedFolders((prev) => {
      const next = new Set(prev);
      if (next.has(path)) {
        next.delete(path);
      } else {
        next.add(path);
      }
      return next;
    });
  };

  const renderFolder = (node: FolderNode, depth: number): React.ReactNode => {
    const isRoot = node.path === '';
    const isCollapsed = !isRoot && collapsedFolders.has(node.path) && !trimmedQuery;

    return (
      <div key={node.path || 'root'}>
        {!isRoot && (
          <button
            type="button"
            onClick={() => toggleFolder(node.path)}
            style={{ paddingLeft: `${depth * 14 + 8}px` }}
            className="w-full flex items-center gap-1.5 pr-3 py-1.5 text-left text-[13px] font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100/80 dark:hover:bg-slate-800/70 rounded-md transition-colors"
          >
            {isCollapsed ? (
              <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            )}
            {isCollapsed ? (
              <Folder className="w-4 h-4 text-slate-400 shrink-0" />
            ) : (
              <FolderOpen className="w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" />
            )}
            <span className="truncate">{node.name}</span>
          </button>
        )}

        {!isCollapsed && (
          <div>
            {node.folders.map((sub) => renderFolder(sub, isRoot ? 0 : depth + 1))}
            {node.files.map((file) => {
              const isActive = file.id === activeFileId;
              const indent = isRoot ? 10 : (depth + 1) * 14 + 14;
              return (
                <div
                  key={file.id}
                  style={{ paddingLeft: `${indent}px` }}
                  className={`group flex items-center justify-between gap-2 pr-2 py-1.5 rounded-md text-[13px] transition-colors ${
                    isActive
                      ? 'bg-blue-50 text-blue-800 font-medium dark:bg-blue-950/60 dark:text-sky-300'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100/80 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => onSelectFile(file.id)}
                    className="flex items-center gap-2 min-w-0 flex-1 text-left"
                  >
                    {getFileIcon(file)}
                    <span className="truncate">{highlightMatch(file.name, searchQuery)}</span>
                  </button>

                  <div className="flex items-center gap-1 shrink-0">
                    <span className="text-[11px] font-mono text-slate-400 dark:text-slate-500 tabular-nums group-hover:hidden">
                      {formatBytes(file.sizeBytes)}
                    </span>
                    {file.isUserAdded ? (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteFile(file.id);
                        }}
                        title={`Remove ${file.name}`}
                        aria-label={`Remove ${file.name}`}
                        className="hidden group-hover:inline-flex p-1 rounded text-slate-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    ) : (
                      <span className="hidden group-hover:inline text-[11px] font-mono text-slate-400 dark:text-slate-500 tabular-nums">
                        {formatBytes(file.sizeBytes)}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  };

  return (
    <aside
      onDragOver={(e) => {
        e.preventDefault();
        setIsDragOver(true);
      }}
      onDragLeave={() => setIsDragOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setIsDragOver(false);
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
          onDropFiles(e.dataTransfer.files);
        }
      }}
      className={`h-full flex flex-col bg-slate-50/70 dark:bg-slate-900/70 border-r border-slate-200 dark:border-slate-800 select-none relative transition-colors ${
        isDragOver ? 'ring-2 ring-inset ring-blue-500 bg-blue-50/40 dark:bg-blue-950/30' : ''
      }`}
    >
      {/* Explorer Header + Category Filter */}
      <div className="p-3 space-y-2.5 border-b border-slate-200/80 dark:border-slate-800">
        <div className="flex items-center justify-between px-0.5">
          <span className="text-xs font-semibold text-slate-600 dark:text-slate-300 tracking-tight">
            Explorer
          </span>
          <span className="text-[11px] font-mono text-slate-400 dark:text-slate-500 tabular-nums">
            {filteredFiles.length} {filteredFiles.length === 1 ? 'file' : 'files'}
          </span>
        </div>

        {/* Interactive category filter segmented bar */}
        <div className="grid grid-cols-4 gap-1 p-0.5 rounded-md bg-slate-200/70 dark:bg-slate-800">
          {(
            [
              { id: 'all', label: 'All' },
              { id: 'code', label: 'Code' },
              { id: 'docs', label: 'Docs' },
              { id: 'data', label: 'Data' },
            ] as const
          ).map((tab) => {
            const active = categoryFilter === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setCategoryFilter(tab.id)}
                className={`py-1 text-[11px] font-medium rounded transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {trimmedQuery && (
          <div className="flex items-center justify-between gap-2 px-0.5 text-[11px] text-slate-500 dark:text-slate-400">
            <span className="truncate">
              Filter: <strong className="font-medium text-slate-800 dark:text-slate-200">{searchQuery.trim()}</strong>
            </span>
            <button
              type="button"
              onClick={onClearSearch}
              className="text-blue-600 dark:text-sky-400 hover:underline shrink-0"
            >
              Clear
            </button>
          </div>
        )}
      </div>

      {/* File Tree */}
      <div className="flex-1 overflow-y-auto p-2 space-y-0.5">
        {filteredFiles.length === 0 ? (
          <div className="px-3 py-8 text-center space-y-2">
            <p className="text-xs font-medium text-slate-600 dark:text-slate-300">
              No matching files
            </p>
            <p className="text-[11px] text-slate-400">
              {trimmedQuery
                ? `No files match "${searchQuery.trim()}".`
                : 'No files in this category.'}
            </p>
            {(trimmedQuery || categoryFilter !== 'all') && (
              <button
                type="button"
                onClick={() => {
                  onClearSearch();
                  setCategoryFilter('all');
                }}
                className="mt-1 px-2.5 py-1 text-[11px] font-medium rounded-md border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-slate-800 transition-colors"
              >
                Reset filters
              </button>
            )}
          </div>
        ) : (
          renderFolder(tree, 0)
        )}
      </div>

      {/* Drag & Drop Hint Footer */}
      <div className="px-3 py-2.5 border-t border-slate-200/80 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2">
        <Upload className="w-3.5 h-3.5 shrink-0 text-slate-400" />
        <span className="truncate">Drop local files here to inspect</span>
      </div>
    </aside>
  );
};
