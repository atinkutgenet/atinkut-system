import React, { useState } from 'react';
import { X } from 'lucide-react';

interface NewFileModalProps {
  open: boolean;
  onClose: () => void;
  onCreateFile: (filename: string, folder: string, initialContent: string) => void;
}

const TEMPLATES: Record<string, string> = {
  php: `<?php\n$heading = "New PHP Page";\n?>\n<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8" />\n  <title><?php echo $heading; ?></title>\n</head>\n<body style="font-family: system-ui, sans-serif; padding: 32px;">\n  <h1><?php echo $heading; ?></h1>\n  <p>Edit this template in Split or Edit mode to preview changes live.</p>\n</body>\n</html>\n`,
  md: `# Untitled Document\n\nWrite Markdown notes, tables, or code snippets here.\n`,
  html: `<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8" />\n  <title>Document</title>\n</head>\n<body style="font-family: system-ui, sans-serif; padding: 32px;">\n  <h1>Hello World</h1>\n  <p>Live HTML preview inside File Viewer.</p>\n</body>\n</html>\n`,
  json: `{\n  "title": "Sample Config",\n  "enabled": true,\n  "items": ["alpha", "beta"]\n}\n`,
  csv: `Name,Role,Department\nAda Lovelace,Architect,Systems\nGrace Hopper,Compiler Lead,Platform\n`,
  ts: `export function greet(name: string): string {\n  return \`Hello, \${name}\`;\n}\n`,
};

export const NewFileModal: React.FC<NewFileModalProps> = ({
  open,
  onClose,
  onCreateFile,
}) => {
  const [filename, setFilename] = useState('notes.md');
  const [folder, setFolder] = useState('');
  const [error, setError] = useState('');

  if (!open) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = filename.trim().replace(/^\/+|\/+$/g, '');
    if (!cleaned) {
      setError('Please enter a valid file name.');
      return;
    }
    const ext = cleaned.includes('.') ? cleaned.split('.').pop()!.toLowerCase() : 'txt';
    const template = TEMPLATES[ext] ?? '';
    onCreateFile(cleaned, folder.trim().replace(/^\/+|\/+$/g, ''), template);
    setError('');
    setFilename('notes.md');
    setFolder('');
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/40 backdrop-blur-[1px] flex items-center justify-center px-4"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Create New File"
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden"
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-slate-800">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
            Create New File
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              File Name
            </label>
            <input
              type="text"
              autoFocus
              value={filename}
              onChange={(e) => setFilename(e.target.value)}
              placeholder="e.g. demo.php, notes.md, data.csv"
              className="w-full px-3 py-2 text-sm rounded-lg bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/25 focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Folder (optional)
            </label>
            <input
              type="text"
              value={folder}
              onChange={(e) => setFolder(e.target.value)}
              placeholder="e.g. docs or src"
              className="w-full px-3 py-2 text-sm rounded-lg bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/25 focus:border-blue-500"
            />
          </div>

          {error && <p className="text-xs text-red-600 dark:text-red-400">{error}</p>}

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium rounded-md text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-medium rounded-md bg-blue-600 hover:bg-blue-700 text-white transition-colors"
            >
              Create File
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
