import React from 'react';
import { TrackId, getLearningTracks } from '../data/learningTracks';
import { Language, TranslationStrings } from '../i18n/translations';
import { TrackIllustration } from './ConceptArtwork';

interface AboutViewProps {
  language: Language;
  t: TranslationStrings;
  onOpenTrack: (id: TrackId) => void;
}

export const AboutView: React.FC<AboutViewProps> = ({
  language,
  t,
  onOpenTrack,
}) => {
  const tracks = getLearningTracks(language);

  return (
    <section className="max-w-5xl mx-auto px-4 md:px-8 py-12 space-y-10">
      <div className="space-y-4">
        <div className="text-xs font-medium text-emerald-700 dark:text-emerald-400">
          {t.aboutEyebrow}
        </div>
        <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight text-slate-900 dark:text-white max-w-2xl text-balance">
          {t.aboutTitle}
        </h1>
        <p className="text-base text-slate-600 dark:text-slate-300 max-w-[68ch] leading-relaxed">
          {t.aboutDesc}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 border-t border-b border-slate-200 dark:border-slate-800 py-8">
        <div>
          <div className="text-2xl font-display font-bold text-slate-900 dark:text-white tabular-nums">
            {t.statTracksTitle}
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {t.statTracksDesc}
          </p>
        </div>
        <div>
          <div className="text-2xl font-display font-bold text-slate-900 dark:text-white">
            {t.statLangTitle}
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {t.statLangDesc}
          </p>
        </div>
        <div>
          <div className="text-2xl font-display font-bold text-slate-900 dark:text-white">
            {t.statLabsTitle}
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {t.statLabsDesc}
          </p>
        </div>
      </div>

      <div className="space-y-4">
        <h2 className="font-display text-xl font-semibold text-slate-900 dark:text-white">
          {t.exploreAllTracks}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {tracks.map((track) => (
            <button
              key={track.id}
              type="button"
              onClick={() => onOpenTrack(track.id)}
              className="text-left p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-emerald-500/60 transition-colors flex flex-col gap-4"
            >
              <div className="h-28 w-full overflow-hidden rounded-lg">
                <TrackIllustration trackId={track.id} />
              </div>
              <div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  {track.accentLabel} · {track.level} · {track.duration}
                </div>
                <div className="font-display text-base font-bold text-slate-900 dark:text-white mt-1">
                  {track.title}
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1.5 leading-relaxed">
                  {track.subtitle}
                </p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};
