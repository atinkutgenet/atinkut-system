import React, { useRef } from 'react';
import {
  FilePlus2,
  FolderOpen,
  Moon,
  PanelLeft,
  Search,
  Sun,
  X,
} from 'lucide-react';
import { WorkspaceFile } from '../types/files';

interface TopFrameBarProps {
  activeFile: WorkspaceFile | null;
  sidebarOpen: boolean;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  searchInputRef: React.RefObject<HTMLInputElement | null>;
  onToggleSidebar: () => void;
  onOpenNewFile: () => void;
  onUploadFiles: (files: FileList) => void;
  isDark: boolean;
  onToggleTheme: () => void;
}

export const TopFrameBar: React.FC<TopFrameBarProps> = ({
  activeFile,
  sidebarOpen,
  searchQuery,
  onSearchChange,
  searchInputRef,
  onToggleSidebar,
  onOpenNewFile,
  onUploadFiles,
  isDark,
  onToggleTheme,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const pathSegments = activeFile
    ? activeFile.path.split('/').filter(Boolean)
    : [];

  return (
    <header className="min-h-[52px] shrink-0 px-4 py-1.5 flex items-center justify-between gap-4 md:gap-6 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 select-none">
      {/* Zone 1: Brand, Sidebar Toggle & Active Breadcrumb */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          type="button"
          onClick={onToggleSidebar}
          aria-label={sidebarOpen ? 'Hide file explorer' : 'Show file explorer'}
          title={sidebarOpen ? 'Hide file explorer' : 'Show file explorer'}
          className="p-2 rounded-md text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
        >
          <PanelLeft className="w-4 h-4" />
        </button>

        <span className="font-display text-base font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0">
          File Viewer
        </span>

        {activeFile && (
          <nav
            aria-label="Breadcrumb"
            className="hidden lg:flex items-center gap-1.5 text-[13px] text-slate-500 dark:text-slate-400 pl-3 ml-1 border-l border-slate-200 dark:border-slate-800 min-w-0 truncate"
          >
            <span className="text-slate-400 dark:text-slate-500 shrink-0">Workspace</span>
            {pathSegments.map((segment, idx) => {
              const isLast = idx === pathSegments.length - 1;
              return (
                <React.Fragment key={`${segment}-${idx}`}>
                  <span aria-hidden="true" className="text-slate-300 dark:text-slate-600 shrink-0">
                    /
                  </span>
                  <span
                    className={
                      isLast
                        ? 'font-medium text-slate-800 dark:text-slate-200 truncate'
                        : 'text-slate-500 dark:text-slate-400 truncate'
                    }
                  >
                    {segment}
                  </span>
                </React.Fragment>
              );
            })}
          </nav>
        )}
      </div>

      {/* Zone 2: Live Top Frame Search Bar (filters leftFrame / file.php) */}
      <div className="flex-1 max-w-md min-w-[140px]">
        <div className="relative flex items-center">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 pointer-events-none" />
          <input
            ref={searchInputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Escape' && searchQuery) {
                onSearchChange('');
              }
            }}
            aria-label="Filter files in sidebar"
            placeholder="Search files..."
            className="w-full pl-8 pr-16 py-1.5 text-xs rounded-lg bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:bg-white dark:focus:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/25 focus:border-blue-500 transition-colors"
          />
          {searchQuery ? (
            <button
              type="button"
              onClick={() => onSearchChange('')}
              aria-label="Clear search filter"
              title="Clear search"
              className="absolute right-2 p-1 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          ) : (
            <kbd className="hidden sm:inline-block pointer-events-none absolute right-2 font-mono text-[10px] px-1.5 py-0.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-400">
              Ctrl K
            </kbd>
          )}
        </div>
      </div>

      {/* Zone 3: Primary Actions */}
      <div className="flex items-center gap-2 shrink-0">
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => {
            if (e.target.files && e.target.files.length > 0) {
              onUploadFiles(e.target.files);
              e.target.value = '';
            }
          }}
        />

        <button
          type="button"
          onClick={onOpenNewFile}
          className="px-3 py-1.5 rounded-md text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
        >
          <FilePlus2 className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">New File</span>
        </button>

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="px-3.5 py-1.5 rounded-md text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
        >
          <FolderOpen className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Open Files</span>
        </button>

        <button
          type="button"
          onClick={onToggleTheme}
          aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
          title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
          className="p-2 rounded-md text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
        >
          {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>
      </div>
    </header>
  );
};
