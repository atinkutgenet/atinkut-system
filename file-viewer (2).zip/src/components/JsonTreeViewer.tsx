import React, { useMemo, useState } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';

interface JsonNodeProps {
  label?: string;
  value: unknown;
  depth: number;
  defaultOpen?: boolean;
}

const JsonNode: React.FC<JsonNodeProps> = ({ label, value, depth, defaultOpen = true }) => {
  const [expanded, setExpanded] = useState(defaultOpen || depth < 2);
  const isArray = Array.isArray(value);
  const isObject = value !== null && typeof value === 'object';

  if (!isObject) {
    let valNode: React.ReactNode;
    if (typeof value === 'string') {
      valNode = <span className="text-emerald-700 dark:text-emerald-400">"{value}"</span>;
    } else if (typeof value === 'number') {
      valNode = <span className="text-orange-700 dark:text-orange-300 tabular-nums">{value}</span>;
    } else if (typeof value === 'boolean') {
      valNode = <span className="text-blue-700 dark:text-sky-400 font-medium">{String(value)}</span>;
    } else {
      valNode = <span className="text-slate-400 italic">null</span>;
    }

    return (
      <div className="flex items-baseline gap-1.5 py-0.5 leading-6 font-mono text-[13px]">
        {label !== undefined && (
          <span className="text-slate-800 dark:text-slate-200 font-medium">
            "{label}":
          </span>
        )}
        {valNode}
      </div>
    );
  }

  const entries = isArray
    ? (value as unknown[]).map((v, idx) => [String(idx), v] as const)
    : Object.entries(value as Record<string, unknown>);

  const openBracket = isArray ? '[' : '{';
  const closeBracket = isArray ? ']' : '}';

  return (
    <div className="font-mono text-[13px] leading-6">
      <button
        type="button"
        onClick={() => setExpanded((prev) => !prev)}
        className="inline-flex items-center gap-1 py-0.5 text-left hover:bg-slate-100 dark:hover:bg-slate-800/80 rounded px-1 -ml-1 transition-colors"
      >
        {expanded ? (
          <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
        ) : (
          <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
        )}
        {label !== undefined && (
          <span className="text-slate-800 dark:text-slate-200 font-medium">
            "{label}":
          </span>
        )}
        <span className="text-slate-500 dark:text-slate-400">
          {openBracket}
          {!expanded && (
            <span className="mx-1 text-xs text-slate-400 tabular-nums">
              {entries.length} {entries.length === 1 ? 'item' : 'items'}
            </span>
          )}
          {!expanded && closeBracket}
        </span>
      </button>

      {expanded && (
        <div className="pl-5 ml-1.5 border-l border-slate-200 dark:border-slate-800">
          {entries.map(([k, v]) => (
            <JsonNode
              key={k}
              label={isArray ? undefined : k}
              value={v}
              depth={depth + 1}
              defaultOpen={depth < 1}
            />
          ))}
          <div className="text-slate-500 dark:text-slate-400 -ml-1">{closeBracket}</div>
        </div>
      )}
    </div>
  );
};

export const JsonTreeViewer: React.FC<{ content: string }> = ({ content }) => {
  const parsed = useMemo(() => {
    try {
      return { ok: true as const, data: JSON.parse(content) };
    } catch (err) {
      return {
        ok: false as const,
        error: err instanceof Error ? err.message : 'Invalid JSON syntax',
      };
    }
  }, [content]);

  if (!parsed.ok) {
    return (
      <div className="p-6 max-w-2xl">
        <div className="p-4 rounded-lg border border-red-200 dark:border-red-900/60 bg-red-50 dark:bg-red-950/30 text-sm text-red-800 dark:text-red-300">
          <p className="font-semibold mb-1">JSON Parse Error</p>
          <p className="font-mono text-xs">{parsed.error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 overflow-auto min-h-full bg-white dark:bg-slate-950">
      <JsonNode value={parsed.data} depth={0} defaultOpen />
    </div>
  );
};
