import React from 'react';
import { TrackId } from '../data/learningTracks';

export const TrackIllustration: React.FC<{ trackId: TrackId }> = ({ trackId }) => {
  if (trackId === 'html') {
    return (
      <svg viewBox="0 0 240 140" className="w-full h-full" fill="none" aria-hidden="true">
        <rect width="240" height="140" rx="8" className="fill-slate-100 dark:fill-slate-800/80" />
        <rect x="20" y="18" width="200" height="104" rx="6" className="fill-white dark:fill-slate-900 stroke-slate-200 dark:stroke-slate-700" strokeWidth="1.2" />
        <rect x="32" y="30" width="70" height="10" rx="3" className="fill-emerald-600/80 dark:fill-emerald-500/80" />
        <rect x="32" y="48" width="176" height="22" rx="4" className="fill-slate-100 dark:fill-slate-800 stroke-slate-200 dark:stroke-slate-700" strokeWidth="1" />
        <text x="42" y="63" className="fill-slate-600 dark:fill-slate-300" fontFamily="monospace" fontSize="10">&lt;header&gt; ... &lt;/header&gt;</text>
        <rect x="32" y="78" width="110" height="30" rx="4" className="fill-slate-100 dark:fill-slate-800 stroke-slate-200 dark:stroke-slate-700" strokeWidth="1" />
        <text x="42" y="96" className="fill-slate-600 dark:fill-slate-300" fontFamily="monospace" fontSize="10">&lt;main&gt;</text>
        <rect x="150" y="78" width="58" height="30" rx="4" className="fill-emerald-50 dark:fill-emerald-950/60 stroke-emerald-300 dark:stroke-emerald-700" strokeWidth="1" />
        <text x="160" y="96" className="fill-emerald-700 dark:fill-emerald-400" fontFamily="monospace" fontSize="9">&lt;aside&gt;</text>
      </svg>
    );
  }

  if (trackId === 'css') {
    return (
      <svg viewBox="0 0 240 140" className="w-full h-full" fill="none" aria-hidden="true">
        <rect width="240" height="140" rx="8" className="fill-slate-100 dark:fill-slate-800/80" />
        <rect x="24" y="24" width="58" height="92" rx="6" className="fill-white dark:fill-slate-900 stroke-sky-500/70" strokeWidth="1.5" />
        <rect x="91" y="24" width="58" height="92" rx="6" className="fill-white dark:fill-slate-900 stroke-slate-300 dark:stroke-slate-700" strokeWidth="1.2" />
        <rect x="158" y="24" width="58" height="92" rx="6" className="fill-white dark:fill-slate-900 stroke-slate-300 dark:stroke-slate-700" strokeWidth="1.2" />
        <circle cx="53" cy="54" r="14" className="fill-sky-100 dark:fill-sky-900/50" />
        <rect x="36" y="78" width="34" height="6" rx="2" className="fill-sky-600 dark:fill-sky-400" />
        <rect x="36" y="90" width="24" height="5" rx="2" className="fill-slate-300 dark:fill-slate-600" />
        <rect x="103" y="42" width="34" height="6" rx="2" className="fill-slate-400 dark:fill-slate-500" />
        <rect x="103" y="56" width="34" height="40" rx="4" className="fill-slate-100 dark:fill-slate-800" />
        <rect x="170" y="42" width="34" height="6" rx="2" className="fill-slate-400 dark:fill-slate-500" />
        <rect x="170" y="56" width="34" height="40" rx="4" className="fill-slate-100 dark:fill-slate-800" />
      </svg>
    );
  }

  if (trackId === 'js') {
    return (
      <svg viewBox="0 0 240 140" className="w-full h-full" fill="none" aria-hidden="true">
        <rect width="240" height="140" rx="8" className="fill-slate-100 dark:fill-slate-800/80" />
        <rect x="20" y="20" width="200" height="100" rx="6" className="fill-slate-900 dark:fill-slate-950 stroke-slate-700" strokeWidth="1.2" />
        <text x="34" y="46" fill="#FBBF24" fontFamily="monospace" fontSize="10.5">function munon() {'{'}</text>
        <text x="44" y="66" fill="#94A3B8" fontFamily="monospace" fontSize="10">toggle("munu");</text>
        <text x="44" y="84" fill="#34D399" fontFamily="monospace" fontSize="10">toggle("push-right");</text>
        <text x="34" y="102" fill="#FBBF24" fontFamily="monospace" fontSize="10.5">{'}'}</text>
      </svg>
    );
  }

  if (trackId === 'php') {
    return (
      <svg viewBox="0 0 240 140" className="w-full h-full" fill="none" aria-hidden="true">
        <rect width="240" height="140" rx="8" className="fill-slate-100 dark:fill-slate-800/80" />
        <rect x="22" y="22" width="196" height="96" rx="6" className="fill-white dark:fill-slate-900 stroke-indigo-300 dark:stroke-indigo-700" strokeWidth="1.2" />
        <text x="36" y="48" className="fill-indigo-600 dark:fill-indigo-400" fontFamily="monospace" fontSize="11" fontWeight="600">&lt;?php</text>
        <text x="36" y="70" className="fill-slate-700 dark:fill-slate-300" fontFamily="monospace" fontSize="10.5">$name = "Atinkut";</text>
        <text x="36" y="90" className="fill-emerald-700 dark:fill-emerald-400" fontFamily="monospace" fontSize="10.5">echo "Hi " . $name;</text>
        <text x="36" y="108" className="fill-indigo-600 dark:fill-indigo-400" fontFamily="monospace" fontSize="11" fontWeight="600">?&gt;</text>
      </svg>
    );
  }

  return (
    <svg viewBox="0 0 240 140" className="w-full h-full" fill="none" aria-hidden="true">
      <rect width="240" height="140" rx="8" className="fill-slate-100 dark:fill-slate-800/80" />
      <rect x="22" y="20" width="196" height="100" rx="6" className="fill-white dark:fill-slate-900 stroke-slate-200 dark:stroke-slate-700" strokeWidth="1.2" />
      <rect x="22" y="20" width="196" height="24" rx="6" className="fill-slate-800 dark:fill-slate-800" />
      <text x="34" y="36" fill="#F8FAFC" fontFamily="monospace" fontSize="10">SELECT * FROM enrollments</text>
      <line x1="22" y1="68" x2="218" y2="68" className="stroke-slate-200 dark:stroke-slate-800" />
      <line x1="22" y1="92" x2="218" y2="92" className="stroke-slate-200 dark:stroke-slate-800" />
      <text x="34" y="60" className="fill-slate-600 dark:fill-slate-300" fontFamily="monospace" fontSize="9.5">101 · Atinkut · 100%</text>
      <text x="34" y="84" className="fill-slate-600 dark:fill-slate-300" fontFamily="monospace" fontSize="9.5">102 · Abebe   ·  75%</text>
      <text x="34" y="108" className="fill-slate-600 dark:fill-slate-300" fontFamily="monospace" fontSize="9.5">103 · Selam   ·  80%</text>
    </svg>
  );
};
