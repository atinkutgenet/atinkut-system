import React, { useState } from 'react';
import { Grid, ImageOff, Maximize2, ZoomIn, ZoomOut } from 'lucide-react';
import { WorkspaceFile } from '../types/files';

export const MediaViewer: React.FC<{ file: WorkspaceFile }> = ({ file }) => {
  const [zoom, setZoom] = useState<number>(100);
  const [checkerboard, setCheckerboard] = useState<boolean>(true);
  const [imgError, setImgError] = useState<boolean>(false);

  const isSvg = file.extension === 'svg';
  const isPdf = file.extension === 'pdf' || file.mimeType === 'application/pdf';

  const mediaSrc = React.useMemo(() => {
    if (file.binaryUrl) return file.binaryUrl;
    if (isSvg && file.content) {
      return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(file.content)}`;
    }
    return '';
  }, [file.binaryUrl, file.content, isSvg]);

  if (isPdf && mediaSrc) {
    return (
      <div className="h-full w-full bg-slate-100 dark:bg-slate-900 flex flex-col">
        <iframe
          src={mediaSrc}
          title={file.name}
          className="w-full h-full border-0"
        />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950">
      <div className="flex items-center justify-between gap-4 px-5 py-2.5 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60">
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setZoom((z) => Math.max(25, z - 25))}
            className="p-1.5 rounded-md text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Zoom out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-xs font-mono text-slate-600 dark:text-slate-300 w-12 text-center tabular-nums">
            {zoom}%
          </span>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.min(300, z + 25))}
            className="p-1.5 rounded-md text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Zoom in"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setZoom(100)}
            className="ml-1 px-2.5 py-1 text-xs font-medium rounded-md text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors inline-flex items-center gap-1 whitespace-nowrap"
          >
            <Maximize2 className="w-3 h-3" />
            <span>Reset</span>
          </button>
        </div>

        <button
          type="button"
          onClick={() => setCheckerboard((c) => !c)}
          className={`px-2.5 py-1 text-xs font-medium rounded-md border transition-colors inline-flex items-center gap-1.5 whitespace-nowrap ${
            checkerboard
              ? 'bg-slate-900 text-white border-slate-900 dark:bg-slate-100 dark:text-slate-900 dark:border-slate-100'
              : 'bg-white text-slate-600 border-slate-200 hover:text-slate-900 dark:bg-slate-900 dark:text-slate-300 dark:border-slate-700'
          }`}
        >
          <Grid className="w-3.5 h-3.5" />
          <span>Transparency Grid</span>
        </button>
      </div>

      <div
        className={`flex-1 overflow-auto flex items-center justify-center p-8 ${
          checkerboard ? 'checkerboard-bg' : 'bg-slate-100 dark:bg-slate-900'
        }`}
      >
        {mediaSrc && !imgError ? (
          <img
            src={mediaSrc}
            alt={file.name}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            style={{
              width: isSvg ? `${Math.round((720 * zoom) / 100)}px` : undefined,
              transform: isSvg ? undefined : `scale(${zoom / 100})`,
              transformOrigin: 'center center',
            }}
            className="max-w-none rounded-lg shadow-sm border border-slate-200/80 dark:border-slate-700/80 transition-transform duration-150 bg-white"
          />
        ) : (
          <div className="flex flex-col items-center justify-center gap-3 p-10 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center max-w-sm">
            <div className="w-11 h-11 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500">
              <ImageOff className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
                Preview unavailable
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                {file.name} cannot be rendered inline in this viewport.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
