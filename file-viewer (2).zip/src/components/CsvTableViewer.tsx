import React, { useMemo, useState } from 'react';
import { ArrowDown, ArrowUp, Search } from 'lucide-react';
import { parseCsv } from '../utils/fileHelpers';

export const CsvTableViewer: React.FC<{ content: string }> = ({ content }) => {
  const { headers, rows } = useMemo(() => parseCsv(content), [content]);
  const [filterText, setFilterText] = useState('');
  const [sortCol, setSortCol] = useState<number | null>(null);
  const [sortAsc, setSortAsc] = useState(true);

  const filteredAndSortedRows = useMemo(() => {
    const q = filterText.trim().toLowerCase();
    let result = q
      ? rows.filter((row) => row.some((cell) => cell.toLowerCase().includes(q)))
      : [...rows];

    if (sortCol !== null) {
      result.sort((a, b) => {
        const valA = a[sortCol] ?? '';
        const valB = b[sortCol] ?? '';
        const numA = Number(valA);
        const numB = Number(valB);
        if (!Number.isNaN(numA) && !Number.isNaN(numB) && valA !== '' && valB !== '') {
          return sortAsc ? numA - numB : numB - numA;
        }
        return sortAsc ? valA.localeCompare(valB) : valB.localeCompare(valA);
      });
    }

    return result;
  }, [rows, filterText, sortCol, sortAsc]);

  const handleSort = (colIdx: number) => {
    if (sortCol === colIdx) {
      setSortAsc((prev) => !prev);
    } else {
      setSortCol(colIdx);
      setSortAsc(true);
    }
  };

  if (headers.length === 0) {
    return (
      <div className="p-8 text-sm text-slate-500 dark:text-slate-400">
        This CSV file appears to be empty.
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-950">
      <div className="flex items-center justify-between gap-4 px-5 py-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50">
        <div className="relative flex-1 max-w-xs">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={filterText}
            onChange={(e) => setFilterText(e.target.value)}
            placeholder="Filter rows..."
            className="w-full pl-8 pr-3 py-1.5 text-xs rounded-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
          />
        </div>
        <div className="text-xs text-slate-500 dark:text-slate-400 tabular-nums whitespace-nowrap">
          {filteredAndSortedRows.length} of {rows.length} rows · {headers.length} columns
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <table className="w-full text-left border-collapse text-[13px]">
          <thead className="sticky top-0 z-10 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
            <tr>
              <th className="w-12 px-3 py-2.5 text-right text-[11px] font-mono text-slate-400 border-r border-slate-200/70 dark:border-slate-800 tabular-nums">
                #
              </th>
              {headers.map((header, idx) => {
                const isSorted = sortCol === idx;
                return (
                  <th key={idx} className="px-4 py-2.5 font-semibold text-slate-700 dark:text-slate-200 whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => handleSort(idx)}
                      className="inline-flex items-center gap-1.5 hover:text-slate-950 dark:hover:text-white transition-colors"
                    >
                      <span>{header}</span>
                      {isSorted &&
                        (sortAsc ? (
                          <ArrowUp className="w-3 h-3 text-blue-600 dark:text-sky-400" />
                        ) : (
                          <ArrowDown className="w-3 h-3 text-blue-600 dark:text-sky-400" />
                        ))}
                    </button>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-900">
            {filteredAndSortedRows.map((row, rIdx) => (
              <tr
                key={rIdx}
                className="hover:bg-slate-50/80 dark:hover:bg-slate-900/50 transition-colors"
              >
                <td className="px-3 py-2 text-right text-[11px] font-mono text-slate-400 border-r border-slate-100 dark:border-slate-900 tabular-nums">
                  {rIdx + 1}
                </td>
                {headers.map((_, cIdx) => (
                  <td
                    key={cIdx}
                    className="px-4 py-2 text-slate-700 dark:text-slate-300 whitespace-nowrap tabular-nums"
                  >
                    {row[cIdx] ?? ''}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
