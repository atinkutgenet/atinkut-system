import React from 'react';
import {
  BookOpen,
  Code2,
  Database,
  Home,
  Info,
  LayoutGrid,
  UserPlus,
  X,
} from 'lucide-react';
import {
  LANGUAGE_OPTIONS,
  Language,
  TranslationStrings,
} from '../i18n/translations';
import { PageView } from './PortalNavbar';

interface PushMenuDrawerProps {
  open: boolean;
  currentView: PageView;
  completedCount: number;
  totalCount: number;
  language: Language;
  t: TranslationStrings;
  onChangeLanguage: (lang: Language) => void;
  onSelect: (view: PageView) => void;
  onClose: () => void;
}

export const PushMenuDrawer: React.FC<PushMenuDrawerProps> = ({
  open,
  currentView,
  completedCount,
  totalCount,
  language,
  t,
  onChangeLanguage,
  onSelect,
  onClose,
}) => {
  const menuItems: { id: PageView; label: string; sublabel: string; icon: React.ReactNode }[] = [
    {
      id: 'learn',
      label: t.navLearnClass,
      sublabel: t.navLearnClassSub,
      icon: <BookOpen className="w-4 h-4" />,
    },
    {
      id: 'more-home',
      label: t.navMoreHome,
      sublabel: t.navMoreHomeSub,
      icon: <LayoutGrid className="w-4 h-4" />,
    },
    {
      id: 'register',
      label: t.navRegister,
      sublabel: t.navRegisterSub,
      icon: <UserPlus className="w-4 h-4" />,
    },
    {
      id: 'php',
      label: 'PHP',
      sublabel: t.navPhpSub,
      icon: <Code2 className="w-4 h-4" />,
    },
    {
      id: 'mysql',
      label: 'MySQL',
      sublabel: t.navMysqlSub,
      icon: <Database className="w-4 h-4" />,
    },
    {
      id: 'about',
      label: t.navAbout,
      sublabel: t.navAboutSub,
      icon: <Info className="w-4 h-4" />,
    },
  ];

  return (
    <>
      {open && (
        <div
          onClick={onClose}
          className="lg:hidden fixed inset-0 top-16 z-30 bg-slate-950/40 backdrop-blur-[1px]"
        />
      )}

      <aside
        aria-label={t.menuTitle}
        className={`fixed top-16 left-0 bottom-0 z-30 w-[280px] bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col transition-transform duration-200 ease-out ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-sm font-semibold text-slate-900 dark:text-white">
              {t.menuTitle}
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 tabular-nums">
              {t.lessonsCompletedOf(completedCount, totalCount)}
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.closeMenu}
            className="lg:hidden p-1.5 rounded-md text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-1.5">
          <button
            type="button"
            onClick={() => onSelect('home')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-left transition-colors border ${
              currentView === 'home'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900 dark:bg-emerald-950/50 dark:border-emerald-800 dark:text-emerald-200'
                : 'border-transparent text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70'
            }`}
          >
            <Home className="w-4 h-4 shrink-0" />
            <div className="min-w-0">
              <div className="text-sm font-semibold truncate">{t.navHome}</div>
              <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                {t.navHomeSub}
              </div>
            </div>
          </button>

          <div className="my-2 border-t border-slate-100 dark:border-slate-800" />

          {menuItems.map((item) => {
            const active = currentView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelect(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-left transition-colors border ${
                  active
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-900 dark:bg-emerald-950/50 dark:border-emerald-800 dark:text-emerald-200'
                    : 'border-transparent text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70'
                }`}
              >
                <span className="shrink-0">{item.icon}</span>
                <div className="min-w-0">
                  <div className="text-sm font-semibold truncate">{item.label}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {item.sublabel}
                  </div>
                </div>
              </button>
            );
          })}
        </nav>

        {/* Drawer Language Switcher */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800 space-y-2">
          <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400 px-1">
            {t.languageLabel}
          </div>
          <div className="grid grid-cols-3 gap-1 p-1 rounded-lg bg-slate-100 dark:bg-slate-800">
            {LANGUAGE_OPTIONS.map((opt) => {
              const active = language === opt.code;
              return (
                <button
                  key={opt.code}
                  type="button"
                  onClick={() => onChangeLanguage(opt.code)}
                  className={`py-1.5 px-2 rounded-md text-xs font-semibold transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {opt.shortLabel}
                </button>
              );
            })}
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 px-1 pt-1">
            {t.drawerFooter}
          </div>
        </div>
      </aside>
    </>
  );
};
