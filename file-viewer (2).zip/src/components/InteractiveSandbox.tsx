import React, { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, Copy, Play, RotateCcw } from 'lucide-react';
import {
  EnrollmentRow,
  SAMPLE_ENROLLMENTS,
  TrackId,
  getLearningTracks,
} from '../data/learningTracks';
import { Language, TranslationStrings } from '../i18n/translations';
import { renderPhpTemplateToHtml } from '../utils/fileHelpers';

interface InteractiveSandboxProps {
  language: Language;
  t: TranslationStrings;
  activeTrackId: TrackId;
  onSelectTrack: (id: TrackId) => void;
  completedTracks: Set<TrackId>;
  onToggleComplete: (id: TrackId) => void;
}

function executeSimpleSql(
  sql: string,
  rows: EnrollmentRow[],
  t: TranslationStrings
): { ok: true; columns: (keyof EnrollmentRow)[]; data: EnrollmentRow[] } | { ok: false; error: string } {
  const cleaned = sql.trim().replace(/;+$/, '').trim();
  if (!/^select\s+/i.test(cleaned)) {
    return {
      ok: false,
      error: t.sqlOnlySelect,
    };
  }

  const selectMatch = cleaned.match(
    /^select\s+([\s\S]+?)\s+from\s+enrollments(?:\s+where\s+([\s\S]+?))?(?:\s+order\s+by\s+([a-z_]+)(?:\s+(asc|desc))?)?(?:\s+limit\s+(\d+))?$/i
  );

  if (!selectMatch) {
    return {
      ok: false,
      error: t.sqlFromHint,
    };
  }

  const allCols: (keyof EnrollmentRow)[] = [
    'id',
    'student_name',
    'track',
    'lessons_done',
    'progress_pct',
    'status',
  ];

  const colExpr = selectMatch[1].trim();
  const columns: (keyof EnrollmentRow)[] =
    colExpr === '*'
      ? allCols
      : colExpr
          .split(',')
          .map((c) => c.trim() as keyof EnrollmentRow)
          .filter((c) => allCols.includes(c));

  if (columns.length === 0) {
    return { ok: false, error: t.sqlNoValidCols + allCols.join(', ') };
  }

  let result = [...rows];
  const whereClause = selectMatch[2]?.trim();

  if (whereClause) {
    const condMatch = whereClause.match(
      /^([a-z_]+)\s*(=|!=|>=|<=|>|<|like)\s*(['"]?)([^'"]+)\3$/i
    );
    if (!condMatch) {
      return {
        ok: false,
        error: t.sqlBadWhere,
      };
    }
    const field = condMatch[1] as keyof EnrollmentRow;
    const op = condMatch[2].toLowerCase();
    const rawVal = condMatch[4];

    if (!allCols.includes(field)) {
      return { ok: false, error: t.sqlUnknownCol(field) };
    }

    result = result.filter((row) => {
      const cell = row[field];
      if (typeof cell === 'number') {
        const num = Number(rawVal);
        if (op === '=') return cell === num;
        if (op === '!=') return cell !== num;
        if (op === '>=') return cell >= num;
        if (op === '<=') return cell <= num;
        if (op === '>') return cell > num;
        if (op === '<') return cell < num;
      }
      const str = String(cell).toLowerCase();
      const target = rawVal.toLowerCase().replace(/%/g, '');
      if (op === 'like') return str.includes(target);
      if (op === '=') return str === target;
      if (op === '!=') return str !== target;
      return true;
    });
  }

  const orderCol = selectMatch[3] as keyof EnrollmentRow | undefined;
  const orderDir = (selectMatch[4] ?? 'asc').toLowerCase();
  if (orderCol && allCols.includes(orderCol)) {
    result.sort((a, b) => {
      const av = a[orderCol];
      const bv = b[orderCol];
      if (typeof av === 'number' && typeof bv === 'number') {
        return orderDir === 'desc' ? bv - av : av - bv;
      }
      return orderDir === 'desc'
        ? String(bv).localeCompare(String(av))
        : String(av).localeCompare(String(bv));
    });
  }

  const limit = selectMatch[5] ? Number(selectMatch[5]) : null;
  if (limit !== null && !Number.isNaN(limit)) {
    result = result.slice(0, limit);
  }

  return { ok: true, columns, data: result };
}

export const InteractiveSandbox: React.FC<InteractiveSandboxProps> = ({
  language,
  t,
  activeTrackId,
  onSelectTrack,
  completedTracks,
  onToggleComplete,
}) => {
  const tracks = useMemo(() => getLearningTracks(language), [language]);
  const track = useMemo(
    () => tracks.find((item) => item.id === activeTrackId) ?? tracks[0],
    [tracks, activeTrackId]
  );

  // Track user-edited code separately; fall back to localized starterCode when unedited
  const [editedCodeMap, setEditedCodeMap] = useState<Partial<Record<TrackId, string>>>({});
  const [copied, setCopied] = useState(false);
  const [runNonce, setRunNonce] = useState(0);

  const currentCode = editedCodeMap[track.id] ?? track.starterCode;

  useEffect(() => {
    setCopied(false);
  }, [track.id]);

  const handleReset = () => {
    setEditedCodeMap((prev) => {
      const next = { ...prev };
      delete next[track.id];
      return next;
    });
    setRunNonce((n) => n + 1);
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(currentCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard fallback ignored
    }
  };

  const isCompleted = completedTracks.has(track.id);

  const renderedOutputHtml = useMemo(() => {
    if (track.id === 'php') {
      return renderPhpTemplateToHtml(currentCode);
    }
    return currentCode;
  }, [track.id, currentCode]);

  const sqlResult = useMemo(() => {
    if (track.id !== 'mysql') return null;
    return executeSimpleSql(currentCode, SAMPLE_ENROLLMENTS, t);
  }, [track.id, currentCode, runNonce, t]);

  return (
    <section className="max-w-6xl mx-auto px-4 md:px-8 py-8 space-y-6">
      {/* Track Selector Strip */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <span>{track.accentLabel}</span>
            <span aria-hidden="true">·</span>
            <span>{track.level}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{track.duration}</span>
          </div>
          <h1 className="font-display text-2xl md:text-3xl font-bold tracking-tight text-slate-900 dark:text-white mt-1">
            {track.title} — {track.amharicTitle}
          </h1>
        </div>

        <button
          type="button"
          onClick={() => onToggleComplete(track.id)}
          className={`px-4 py-2 rounded-lg text-xs font-semibold border transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0 ${
            isCompleted
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800 dark:bg-emerald-950/60 dark:border-emerald-800 dark:text-emerald-300'
              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 dark:bg-slate-900 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>{isCompleted ? t.lessonCompleted : t.markComplete}</span>
        </button>
      </div>

      {/* Track Tabs */}
      <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-lg bg-slate-200/70 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 w-fit">
        {tracks.map((item) => {
          const active = item.id === track.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectTrack(item.id)}
              className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                active
                  ? 'bg-white dark:bg-slate-800 text-slate-950 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white'
              }`}
            >
              {item.title}
            </button>
          );
        })}
      </div>

      {/* Two-Zone Interactive Sandbox */}
      <div className="grid grid-cols-1 lg:grid-cols-12 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden">
        {/* Left Zone: Editable Code / SQL Editor */}
        <div className="lg:col-span-6 flex flex-col border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-slate-800">
          <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/80 flex items-center justify-between gap-2">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
              {track.id === 'mysql' ? t.sqlEditor : t.codeEditor}
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleReset}
                className="px-2.5 py-1 rounded text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors inline-flex items-center gap-1 whitespace-nowrap"
              >
                <RotateCcw className="w-3 h-3" />
                <span>{t.reset}</span>
              </button>
              <button
                type="button"
                onClick={handleCopy}
                className="px-2.5 py-1 rounded text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors inline-flex items-center gap-1 whitespace-nowrap"
              >
                <Copy className="w-3 h-3" />
                <span>{copied ? t.copied : t.copy}</span>
              </button>
              <button
                type="button"
                onClick={() => setRunNonce((n) => n + 1)}
                className="px-3 py-1 rounded text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 dark:bg-emerald-600 dark:hover:bg-emerald-500 transition-colors inline-flex items-center gap-1 whitespace-nowrap"
              >
                <Play className="w-3 h-3" />
                <span>{t.run}</span>
              </button>
            </div>
          </div>

          <textarea
            value={currentCode}
            onChange={(e) =>
              setEditedCodeMap((prev) => ({ ...prev, [track.id]: e.target.value }))
            }
            spellCheck={false}
            aria-label={`${track.title} ${t.codeEditor}`}
            className="w-full h-[360px] lg:h-[420px] p-4 font-mono text-[13px] leading-relaxed bg-slate-950 text-slate-100 resize-none focus:outline-none"
          />
        </div>

        {/* Right Zone: Live Output Stage */}
        <div className="lg:col-span-6 flex flex-col bg-white dark:bg-slate-950">
          <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/80 flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
              {track.id === 'mysql' ? t.queryResultTable : t.liveOutputPreview}
            </span>
            <span className="text-xs font-mono text-slate-400 tabular-nums">
              {track.id === 'mysql' && sqlResult?.ok
                ? t.rowsCount(sqlResult.data.length)
                : t.sandboxed}
            </span>
          </div>

          <div className="flex-1 min-h-[360px] lg:min-h-[420px]">
            {track.id === 'mysql' ? (
              <div className="p-4 h-full overflow-auto">
                {sqlResult && !sqlResult.ok ? (
                  <div className="p-4 rounded-lg border border-red-200 dark:border-red-900/60 bg-red-50 dark:bg-red-950/30 text-xs text-red-800 dark:text-red-300 leading-relaxed">
                    <p className="font-semibold mb-1">{t.queryNotice}</p>
                    <p>{sqlResult.error}</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead className="bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
                        <tr>
                          {sqlResult?.ok &&
                            sqlResult.columns.map((col) => (
                              <th
                                key={col}
                                className="px-3.5 py-2.5 font-mono font-semibold text-slate-700 dark:text-slate-200 whitespace-nowrap"
                              >
                                {col}
                              </th>
                            ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {sqlResult?.ok &&
                          sqlResult.data.map((row) => (
                            <tr
                              key={row.id}
                              className="hover:bg-slate-50 dark:hover:bg-slate-900/60"
                            >
                              {sqlResult.columns.map((col) => (
                                <td
                                  key={col}
                                  className="px-3.5 py-2.5 text-slate-700 dark:text-slate-300 tabular-nums whitespace-nowrap"
                                >
                                  {String(row[col])}
                                </td>
                              ))}
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                )}

                <div className="mt-4 flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      setEditedCodeMap((prev) => ({
                        ...prev,
                        mysql: 'SELECT * FROM enrollments ORDER BY id ASC;',
                      }))
                    }
                    className="px-2.5 py-1 text-[11px] rounded border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
                  >
                    {t.allRows}
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setEditedCodeMap((prev) => ({
                        ...prev,
                        mysql:
                          "SELECT student_name, track, status FROM enrollments WHERE status = 'Completed';",
                      }))
                    }
                    className="px-2.5 py-1 text-[11px] rounded border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
                  >
                    {t.completedOnly}
                  </button>
                </div>
              </div>
            ) : (
              <iframe
                key={`${track.id}-${language}-${runNonce}`}
                title={`${track.title} ${t.liveOutputPreview}`}
                sandbox="allow-scripts"
                srcDoc={renderedOutputHtml}
                className="w-full h-full min-h-[360px] lg:min-h-[420px] border-0 bg-white"
              />
            )}
          </div>
        </div>
      </div>

      {/* Lesson Objectives Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
        {track.objectives.map((obj, idx) => (
          <div
            key={idx}
            className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
          >
            <div className="text-xs font-mono text-emerald-700 dark:text-emerald-400 font-semibold tabular-nums">
              {t.learningGoalPrefix(`0${idx + 1}`)}
            </div>
            <p className="text-sm text-slate-700 dark:text-slate-300 mt-1.5 leading-relaxed">
              {obj}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
};
