import React, { useState } from 'react';
import { TranslationStrings } from '../i18n/translations';

interface AuthViewsProps {
  mode: 'login' | 'register';
  t: TranslationStrings;
  onSwitchMode: (mode: 'login' | 'register') => void;
  onSuccess: (name: string) => void;
  onCancel: () => void;
}

export const AuthViews: React.FC<AuthViewsProps> = ({
  mode,
  t,
  onSwitchMode,
  onSuccess,
  onCancel,
}) => {
  const [name, setName] = useState(mode === 'login' ? 'አትንኩት' : '');
  const [email, setEmail] = useState('atinkut@example.com');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setError(t.missingCreds);
      return;
    }
    const displayName = name.trim() || email.split('@')[0] || 'Atinkut';
    onSuccess(displayName);
  };

  return (
    <section className="max-w-md mx-auto px-4 py-14">
      <div className="p-6 md:p-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
            {mode === 'login' ? t.signInTitle : t.registerTitle}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {mode === 'login' ? t.signInSubtitle : t.registerSubtitle}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'register' && (
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                {t.fullName}
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t.fullNamePlaceholder}
                className="w-full px-3 py-2 text-sm rounded-lg bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/25 focus:border-emerald-600"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t.emailAddress}
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="atinkut@example.com"
              className="w-full px-3 py-2 text-sm rounded-lg bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/25 focus:border-emerald-600"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t.password}
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={t.passwordPlaceholder}
              className="w-full px-3 py-2 text-sm rounded-lg bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/25 focus:border-emerald-600"
            />
          </div>

          {error && (
            <p className="text-xs text-red-600 dark:text-red-400">{error}</p>
          )}

          <div className="flex items-center justify-between gap-3 pt-2">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              {t.cancel}
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-lg text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 dark:bg-emerald-600 dark:hover:bg-emerald-500 transition-colors"
            >
              {mode === 'login' ? t.signInBtn : t.completeRegBtn}
            </button>
          </div>
        </form>

        <div className="pt-4 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between">
          <span>{mode === 'login' ? t.newHere : t.alreadyEnrolled}</span>
          <button
            type="button"
            onClick={() => {
              setError('');
              onSwitchMode(mode === 'login' ? 'register' : 'login');
            }}
            className="font-semibold text-emerald-700 dark:text-emerald-400 hover:underline"
          >
            {mode === 'login' ? t.registerHere : t.signInHere}
          </button>
        </div>
      </div>
    </section>
  );
};
