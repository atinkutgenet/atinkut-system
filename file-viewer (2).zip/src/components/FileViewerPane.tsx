import React, { useEffect, useMemo, useState } from 'react';
import {
  Check,
  Code2,
  Columns2,
  Copy,
  Download,
  Eye,
  FileText,
  FolderOpen,
  Pencil,
  Search,
  WrapText,
  X,
} from 'lucide-react';
import { ViewMode, WorkspaceFile } from '../types/files';
import {
  countLines,
  formatBytes,
  isPreviewable,
  renderPhpTemplateToHtml,
} from '../utils/fileHelpers';
import { CodeViewer } from '../utils/syntaxHighlight';
import { CsvTableViewer } from './CsvTableViewer';
import { JsonTreeViewer } from './JsonTreeViewer';
import { MarkdownRenderer } from './MarkdownRenderer';
import { MediaViewer } from './MediaViewer';

interface FileViewerPaneProps {
  openTabs: WorkspaceFile[];
  activeFile: WorkspaceFile | null;
  onSelectTab: (fileId: string) => void;
  onCloseTab: (fileId: string) => void;
  onUpdateFileContent: (fileId: string, newContent: string) => void;
  onNavigateByFileName: (name: string) => void;
  onUploadFiles: (files: FileList) => void;
}

export const FileViewerPane: React.FC<FileViewerPaneProps> = ({
  openTabs,
  activeFile,
  onSelectTab,
  onCloseTab,
  onUpdateFileContent,
  onNavigateByFileName,
  onUploadFiles,
}) => {
  const [viewMode, setViewMode] = useState<ViewMode>('preview');
  const [wrapLines, setWrapLines] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [showFind, setShowFind] = useState<boolean>(false);
  const [findQuery, setFindQuery] = useState<string>('');

  // Choose sensible default view mode when switching files
  useEffect(() => {
    if (!activeFile) return;
    if (isPreviewable(activeFile)) {
      setViewMode('preview');
    } else {
      setViewMode('source');
    }
    setFindQuery('');
    setShowFind(false);
  }, [activeFile?.id]);

  // Keyboard shortcut Ctrl/Cmd+F inside viewer
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'f') {
        if (activeFile && activeFile.category !== 'media') {
          e.preventDefault();
          setShowFind(true);
          if (viewMode === 'preview') {
            setViewMode('source');
          }
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [activeFile, viewMode]);

  const matchCount = useMemo(() => {
    if (!activeFile || !findQuery.trim()) return 0;
    const q = findQuery.toLowerCase();
    const text = activeFile.content.toLowerCase();
    let count = 0;
    let idx = text.indexOf(q);
    while (idx !== -1) {
      count++;
      idx = text.indexOf(q, idx + q.length);
    }
    return count;
  }, [activeFile, findQuery]);

  const handleCopy = async () => {
    if (!activeFile) return;
    try {
      await navigator.clipboard.writeText(activeFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard fallback ignored cleanly
    }
  };

  const handleDownload = () => {
    if (!activeFile) return;
    if (activeFile.binaryUrl) {
      const a = document.createElement('a');
      a.href = activeFile.binaryUrl;
      a.download = activeFile.name;
      a.click();
      return;
    }
    const blob = new Blob([activeFile.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeFile.name;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!activeFile) {
    return (
      <main className="flex-1 h-full flex flex-col items-center justify-center p-8 bg-white dark:bg-slate-950 text-center">
        <div className="max-w-md space-y-4">
          <div className="w-12 h-12 mx-auto rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400">
            <FileText className="w-6 h-6" />
          </div>
          <h2 className="font-display text-lg font-semibold text-slate-900 dark:text-white">
            No file selected
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
            Choose a file from the left explorer—such as{' '}
            <button
              type="button"
              onClick={() => onNavigateByFileName('learn.php')}
              className="font-mono text-blue-600 dark:text-sky-400 hover:underline"
            >
              learn.php
            </button>{' '}
            or{' '}
            <button
              type="button"
              onClick={() => onNavigateByFileName('file.php')}
              className="font-mono text-blue-600 dark:text-sky-400 hover:underline"
            >
              file.php
            </button>
            —or open local files from your device.
          </p>
          <div className="pt-2 flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => onNavigateByFileName('learn.php')}
              className="px-4 py-2 rounded-md text-xs font-medium bg-slate-900 text-white hover:bg-slate-800 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white transition-colors"
            >
              Open learn.php
            </button>
            <label className="px-4 py-2 rounded-md text-xs font-medium border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-900 cursor-pointer transition-colors inline-flex items-center gap-1.5">
              <FolderOpen className="w-3.5 h-3.5" />
              <span>Browse Local File</span>
              <input
                type="file"
                multiple
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files.length > 0) {
                    onUploadFiles(e.target.files);
                    e.target.value = '';
                  }
                }}
              />
            </label>
          </div>
        </div>
      </main>
    );
  }

  const canPreview = isPreviewable(activeFile);
  const canEdit = activeFile.category !== 'media' && !activeFile.binaryUrl;
  const canSplit = canPreview && canEdit && activeFile.category !== 'media';
  const lineCount = activeFile.binaryUrl ? 0 : countLines(activeFile.content);

  const renderPreviewContent = () => {
    const ext = activeFile.extension;

    if (activeFile.category === 'media') {
      return <MediaViewer file={activeFile} />;
    }

    if (ext === 'md' || ext === 'markdown') {
      return (
        <div className="h-full overflow-auto bg-white dark:bg-slate-950">
          <MarkdownRenderer content={activeFile.content} />
        </div>
      );
    }

    if (ext === 'csv') {
      return <CsvTableViewer content={activeFile.content} />;
    }

    if (ext === 'json') {
      return <JsonTreeViewer content={activeFile.content} />;
    }

    if (ext === 'html' || ext === 'htm' || ext === 'php') {
      // Special interactive frameset map if viewing an HTML <frameset> definition
      if (/<frameset\b/i.test(activeFile.content)) {
        return (
          <div className="h-full overflow-auto bg-slate-50 dark:bg-slate-950 p-6 md:p-10">
            <div className="max-w-4xl mx-auto space-y-6">
              <div>
                <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                  Frameset Blueprint Preview
                </h2>
                <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                  This document defines a classic three-frame layout. Click any frame region below to inspect its target file.
                </p>
              </div>

              <div className="rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden bg-white dark:bg-slate-900 shadow-xs">
                {/* topFrame: 7% */}
                <button
                  type="button"
                  onClick={() => onNavigateByFileName('icon.php')}
                  className="w-full text-left px-5 py-3.5 bg-blue-50/70 dark:bg-blue-950/40 hover:bg-blue-100/80 dark:hover:bg-blue-950/70 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4 transition-colors"
                >
                  <div>
                    <span className="text-xs font-mono text-blue-700 dark:text-sky-400 font-semibold">
                      topFrame
                    </span>
                    <span className="mx-2 text-slate-300 dark:text-slate-700">·</span>
                    <span className="text-sm font-medium text-slate-900 dark:text-slate-100">
                      icon.php
                    </span>
                  </div>
                  <span className="text-xs font-mono text-slate-500 dark:text-slate-400 tabular-nums">
                    rows="7%"
                  </span>
                </button>

                {/* Bottom 93% split: 20% / 80% */}
                <div className="grid grid-cols-1 md:grid-cols-5 min-h-[300px]">
                  <button
                    type="button"
                    onClick={() => onNavigateByFileName('file.php')}
                    className="md:col-span-1 text-left p-5 bg-slate-50 dark:bg-slate-900/60 hover:bg-slate-100 dark:hover:bg-slate-800/70 border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-800 flex flex-col justify-between transition-colors"
                  >
                    <div>
                      <div className="text-xs font-mono text-slate-500 dark:text-slate-400 font-semibold">
                        leftFrame
                      </div>
                      <div className="text-sm font-semibold text-slate-900 dark:text-white mt-1">
                        file.php
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                        Navigation & directory listing
                      </p>
                    </div>
                    <span className="text-xs font-mono text-slate-400 tabular-nums mt-4">
                      cols="20%"
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onNavigateByFileName('learn.php')}
                    className="md:col-span-4 text-left p-6 bg-white dark:bg-slate-950 hover:bg-slate-50/70 dark:hover:bg-slate-900/40 flex flex-col justify-between transition-colors"
                  >
                    <div>
                      <div className="text-xs font-mono text-emerald-700 dark:text-emerald-400 font-semibold">
                        frame (main)
                      </div>
                      <div className="text-base font-semibold text-slate-900 dark:text-white mt-1">
                        learn.php
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-400 mt-2 max-w-lg leading-relaxed">
                        Primary content viewport displaying documentation, previews, and active file output.
                      </p>
                    </div>
                    <span className="text-xs font-mono text-slate-400 tabular-nums mt-6">
                      cols="80%"
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      }

      // If viewing file.php, provide an interactive list preview that navigates inside the app
      const resolvedHtml =
        ext === 'php' ? renderPhpTemplateToHtml(activeFile.content) : activeFile.content;

      // Intercept target="frame" links inside iframe preview via tiny inline handler? No scripts needed if we inject a base or just render cleanly in sandboxed iframe!
      return (
        <div className="h-full w-full bg-white">
          <iframe
            title={`Preview of ${activeFile.name}`}
            sandbox="allow-same-origin"
            srcDoc={resolvedHtml}
            className="w-full h-full border-0 bg-white"
          />
        </div>
      );
    }

    return (
      <CodeViewer
        content={activeFile.content}
        extension={activeFile.extension}
        wrapLines={wrapLines}
        searchQuery={findQuery}
      />
    );
  };

  return (
    <main className="flex-1 min-w-0 h-full flex flex-col bg-white dark:bg-slate-950">
      {/* Open Tabs Strip */}
      {openTabs.length > 0 && (
        <div className="flex items-center overflow-x-auto bg-slate-100/80 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-2 pt-1.5 gap-1 shrink-0">
          {openTabs.map((tab) => {
            const isActive = tab.id === activeFile.id;
            return (
              <div
                key={tab.id}
                className={`group flex items-center gap-2 px-3 py-1.5 rounded-t-md text-xs border border-b-0 transition-colors shrink-0 max-w-[200px] ${
                  isActive
                    ? 'bg-white dark:bg-slate-950 text-slate-900 dark:text-white border-slate-200 dark:border-slate-800 font-medium'
                    : 'bg-transparent border-transparent text-slate-600 dark:text-slate-400 hover:bg-slate-200/60 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                <button
                  type="button"
                  onClick={() => onSelectTab(tab.id)}
                  className="truncate text-left"
                >
                  {tab.name}
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onCloseTab(tab.id);
                  }}
                  aria-label={`Close ${tab.name}`}
                  className={`p-0.5 rounded hover:bg-slate-200 dark:hover:bg-slate-800 transition-opacity ${
                    isActive ? 'opacity-70 hover:opacity-100' : 'opacity-0 group-hover:opacity-70 hover:!opacity-100'
                  }`}
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* File Toolbar & Unboxed Metadata Strip */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 shrink-0">
        {/* Clean unboxed file metadata */}
        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 min-w-0">
          <span className="font-semibold text-slate-900 dark:text-slate-100 truncate">
            {activeFile.name}
          </span>
          <span aria-hidden="true">·</span>
          <span className="whitespace-nowrap">{activeFile.language}</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono tabular-nums whitespace-nowrap">
            {formatBytes(activeFile.sizeBytes)}
          </span>
          {lineCount > 0 && (
            <>
              <span aria-hidden="true" className="hidden sm:inline">·</span>
              <span className="hidden sm:inline font-mono tabular-nums whitespace-nowrap">
                {lineCount} lines
              </span>
            </>
          )}
          {activeFile.encoding && (
            <>
              <span aria-hidden="true" className="hidden md:inline">·</span>
              <span className="hidden md:inline font-mono whitespace-nowrap">
                {activeFile.encoding}
              </span>
            </>
          )}
        </div>

        {/* View Switcher & File Actions */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Mode Segmented Control */}
          {(canPreview || canEdit) && (
            <div className="flex items-center p-0.5 rounded-md bg-slate-100 dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
              {canPreview && (
                <button
                  type="button"
                  onClick={() => setViewMode('preview')}
                  className={`px-2.5 py-1 text-xs font-medium rounded transition-colors inline-flex items-center gap-1.5 whitespace-nowrap ${
                    viewMode === 'preview'
                      ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Preview</span>
                </button>
              )}

              {canEdit && (
                <button
                  type="button"
                  onClick={() => setViewMode('source')}
                  className={`px-2.5 py-1 text-xs font-medium rounded transition-colors inline-flex items-center gap-1.5 whitespace-nowrap ${
                    viewMode === 'source'
                      ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <Code2 className="w-3.5 h-3.5" />
                  <span>Source</span>
                </button>
              )}

              {canSplit && (
                <button
                  type="button"
                  onClick={() => setViewMode('split')}
                  className={`hidden lg:inline-flex px-2.5 py-1 text-xs font-medium rounded transition-colors items-center gap-1.5 whitespace-nowrap ${
                    viewMode === 'split'
                      ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <Columns2 className="w-3.5 h-3.5" />
                  <span>Split</span>
                </button>
              )}

              {canEdit && (
                <button
                  type="button"
                  onClick={() => setViewMode('edit')}
                  className={`px-2.5 py-1 text-xs font-medium rounded transition-colors inline-flex items-center gap-1.5 whitespace-nowrap ${
                    viewMode === 'edit'
                      ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <Pencil className="w-3.5 h-3.5" />
                  <span>Edit</span>
                </button>
              )}
            </div>
          )}

          {canEdit && viewMode === 'source' && (
            <>
              <button
                type="button"
                onClick={() => setShowFind((s) => !s)}
                title="Find in file (Ctrl+F)"
                className={`p-1.5 rounded-md border text-xs transition-colors ${
                  showFind
                    ? 'bg-blue-50 border-blue-200 text-blue-700 dark:bg-blue-950/60 dark:border-blue-800 dark:text-sky-300'
                    : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Search className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => setWrapLines((w) => !w)}
                title={wrapLines ? 'Disable word wrap' : 'Enable word wrap'}
                className={`p-1.5 rounded-md border text-xs transition-colors ${
                  wrapLines
                    ? 'bg-slate-900 border-slate-900 text-white dark:bg-slate-100 dark:border-slate-100 dark:text-slate-900'
                    : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <WrapText className="w-3.5 h-3.5" />
              </button>
            </>
          )}

          {canEdit && (
            <button
              type="button"
              onClick={handleCopy}
              className="px-2.5 py-1.5 rounded-md border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Copy</span>
                </>
              )}
            </button>
          )}

          <button
            type="button"
            onClick={handleDownload}
            className="px-2.5 py-1.5 rounded-md border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Download</span>
          </button>
        </div>
      </div>

      {/* Optional In-File Search Bar */}
      {showFind && canEdit && viewMode === 'source' && (
        <div className="flex items-center justify-between gap-3 px-4 py-2 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-2 flex-1 max-w-sm">
            <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <input
              type="text"
              autoFocus
              value={findQuery}
              onChange={(e) => setFindQuery(e.target.value)}
              placeholder="Find in file..."
              className="w-full px-2 py-1 text-xs rounded bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/25 focus:border-blue-500"
            />
          </div>
          <div className="flex items-center gap-3">
            {findQuery && (
              <span className="text-xs font-mono text-slate-500 dark:text-slate-400 tabular-nums">
                {matchCount} {matchCount === 1 ? 'match' : 'matches'}
              </span>
            )}
            <button
              type="button"
              onClick={() => {
                setShowFind(false);
                setFindQuery('');
              }}
              aria-label="Close find bar"
              className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-h-0 overflow-hidden">
        {viewMode === 'preview' && canPreview && (
          <div className="h-full overflow-auto">{renderPreviewContent()}</div>
        )}

        {viewMode === 'source' && canEdit && (
          <div className="h-full overflow-auto">
            <CodeViewer
              content={activeFile.content}
              extension={activeFile.extension}
              wrapLines={wrapLines}
              searchQuery={findQuery}
            />
          </div>
        )}

        {viewMode === 'split' && canSplit && (
          <div className="h-full grid grid-cols-2 divide-x divide-slate-200 dark:divide-slate-800">
            <div className="h-full overflow-auto">
              <textarea
                value={activeFile.content}
                onChange={(e) => onUpdateFileContent(activeFile.id, e.target.value)}
                spellCheck={false}
                aria-label={`Edit ${activeFile.name}`}
                className="w-full h-full p-5 font-mono text-[13px] leading-[1.65] bg-slate-50/50 dark:bg-slate-950 text-slate-800 dark:text-slate-200 resize-none focus:outline-none"
              />
            </div>
            <div className="h-full overflow-auto">{renderPreviewContent()}</div>
          </div>
        )}

        {viewMode === 'edit' && canEdit && (
          <div className="h-full flex flex-col">
            <textarea
              value={activeFile.content}
              onChange={(e) => onUpdateFileContent(activeFile.id, e.target.value)}
              spellCheck={false}
              aria-label={`Edit ${activeFile.name}`}
              className="w-full flex-1 p-6 font-mono text-[13px] leading-[1.65] bg-white dark:bg-slate-950 text-slate-800 dark:text-slate-200 resize-none focus:outline-none"
            />
          </div>
        )}
      </div>
    </main>
  );
};
