import { WorkspaceFile } from '../types/files';

const learnPhpContent = `<?php
$appTitle = "File Viewer";
$rootDir = "/workspace";
$leftFrame = "file.php";
$topFrame = "icon.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title><?php echo $appTitle; ?> — Workspace Guide</title>
  <style>
    body {
      font-family: 'DM Sans', system-ui, -apple-system, sans-serif;
      color: #0f172a;
      line-height: 1.65;
      margin: 0;
      padding: 36px 40px;
      background: #ffffff;
    }
    h1 {
      font-size: 26px;
      font-weight: 700;
      letter-spacing: -0.02em;
      margin: 0 0 10px 0;
      color: #0f172a;
    }
    .subtitle {
      color: #475569;
      font-size: 15px;
      margin: 0 0 28px 0;
      max-width: 64ch;
    }
    h2 {
      font-size: 16px;
      font-weight: 600;
      margin: 28px 0 10px 0;
      color: #0f172a;
    }
    p {
      margin: 0 0 14px 0;
      font-size: 14.5px;
      color: #334155;
      max-width: 68ch;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 16px 0 24px 0;
      font-size: 13.5px;
    }
    th, td {
      text-align: left;
      padding: 10px 12px;
      border-bottom: 1px solid #e2e8f0;
    }
    th {
      font-weight: 600;
      color: #475569;
      background: #f8fafc;
    }
    code {
      font-family: 'JetBrains Mono', ui-monospace, monospace;
      font-size: 12.5px;
      background: #f1f5f9;
      padding: 2px 6px;
      border-radius: 4px;
      color: #0f172a;
    }
    .divider {
      height: 1px;
      background: #e2e8f0;
      margin: 26px 0;
    }
  </style>
</head>
<body>
  <h1><?php echo $appTitle; ?></h1>
  <p class="subtitle">
    Modernized three-pane workspace preserving the original HTML frameset structure: a compact top action frame, a 20% left directory tree, and an 80% main inspection pane.
  </p>

  <div class="divider"></div>

  <h2>1. Frame Architecture Mapping</h2>
  <p>
    Legacy HTML <code>&lt;frameset&gt;</code> layouts split documents across separate browsing contexts. This application replaces those frames with responsive, resizable panes that share live state, tabs, and keyboard navigation.
  </p>

  <table>
    <thead>
      <tr>
        <th>Original Frame</th>
        <th>Allocation</th>
        <th>Source File</th>
        <th>Modern Pane Role</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><code>topFrame</code></td>
        <td>7% height</td>
        <td><code>icon.php</code></td>
        <td>Header bar with breadcrumbs, file search, upload, and theme controls</td>
      </tr>
      <tr>
        <td><code>leftFrame</code></td>
        <td>20% width</td>
        <td><code>file.php</code></td>
        <td>Resizable directory explorer with instant filtering and drag-and-drop</td>
      </tr>
      <tr>
        <td><code>frame</code></td>
        <td>80% width</td>
        <td><code>learn.php</code></td>
        <td>Multi-format viewer supporting Preview, Source, Split, and Live Edit</td>
      </tr>
    </tbody>
  </table>

  <h2>2. Inspecting &amp; Loading Real Files</h2>
  <p>
    Select any file in the left explorer—including <code>icon.php</code>, <code>file.php</code>, <code>index.html</code>, Markdown notes, CSV tables, JSON schemas, or SVG diagrams—or click <strong>Open Files</strong> in the top bar to load documents directly from your computer.
  </p>
  <p>
    Switch between <strong>Preview</strong>, <strong>Source</strong>, <strong>Split</strong>, and <strong>Edit</strong> in the toolbar above to inspect markup, edit template code live, search within a file, or export changes.
  </p>
</body>
</html>`;

const filePhpContent = `<?php
/**
 * leftFrame — Directory & File Listing (file.php)
 * Filters workspace files by keyword (?q=...) from topFrame
 * and routes selected files into target="frame".
 */
$directory = __DIR__;
$query = isset($_GET['q']) ? trim($_GET['q']) : '';
$entries = array_diff(scandir($directory), ['.', '..']);
if ($query !== '') {
  $entries = array_filter($entries, fn($f) => stripos($f, $query) !== false);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Directory Explorer</title>
</head>
<body style="font-family: system-ui, sans-serif; padding: 16px; color: #0f172a;">
  <h3 style="font-size: 13px; font-weight: 600; margin: 0 0 12px 0; color: #475569;">
    Workspace Files
  </h3>
  <ul style="list-style: none; padding: 0; margin: 0; font-size: 13.5px; line-height: 2;">
    <li><a href="learn.php" target="frame">learn.php</a></li>
    <li><a href="icon.php" target="frame">icon.php</a></li>
    <li><a href="file.php" target="frame">file.php</a></li>
    <li><a href="index.html" target="frame">index.html</a></li>
    <li><a href="docs/migration-guide.md" target="frame">docs/migration-guide.md</a></li>
  </ul>
</body>
</html>`;

const iconPhpContent = `<?php
/**
 * topFrame — Application Header & Search Bar (icon.php)
 * Renders the top 7% navigation strip and submits keyword
 * queries to filter files inside leftFrame (file.php).
 */
$brand = "File Viewer";
$date = date("M j, Y");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Top Frame</title>
</head>
<body style="margin: 0; padding: 10px 20px; font-family: system-ui, sans-serif; background: #f8fafc; border-bottom: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: space-between; gap: 16px;">
  <div style="font-weight: 700; font-size: 15px; color: #0f172a;">
    <?php echo $brand; ?>
  </div>
  <form action="file.php" method="get" target="leftFrame" style="display: flex; align-items: center; gap: 8px; margin: 0;">
    <input type="search" name="q" placeholder="Search files..." style="padding: 5px 10px; font-size: 13px; border: 1px solid #cbd5e1; border-radius: 6px; width: 220px;" />
    <button type="submit" style="padding: 5px 12px; font-size: 13px; background: #2563eb; color: #ffffff; border: none; border-radius: 6px; cursor: pointer;">Filter</button>
  </form>
  <div style="font-size: 12.5px; color: #64748b;">
    Root: /workspace &middot; <?php echo $date; ?>
  </div>
</body>
</html>`;

const framesetHtmlContent = `<!DOCTYPE html>
<html>
<head>
    <title>File Viewer</title>
</head>
<frameset rows="7%,93%">
    <frame src="icon.php" name="topFrame">
    
    <frameset cols="20%,80%">
        <frame src="file.php" name="leftFrame">
        
        <frame src="learn.php" name="frame">
    </frameset>
</frameset>
</html>`;

const migrationGuideMd = `# Frameset to Modern Multi-Pane Architecture

Replacing HTML4 \`<frameset>\` elements with a modern React layout preserves the spatial clarity of the three-pane workspace while eliminating frame isolation issues.

## Key Improvements Over \`<frameset>\`

1. **Shared Application State**: Clicking a file in \`leftFrame\` updates breadcrumbs in \`topFrame\` and opens a tab in \`frame\` without full-page reloads.
2. **Resizable Split Panes**: Drag the divider between the 20% sidebar and 80% viewer pane smoothly to inspect wide tables or code files.
3. **Client-Side Local File Inspection**: Open local \`.php\`, \`.html\`, \`.md\`, \`.csv\`, \`.json\`, \`.svg\`, \`.pdf\`, or image files directly using the browser File API—zero server upload required.

## Supported Inspection Modes

| Format | Default View | Alternate Views |
| --- | --- | --- |
| PHP & HTML | Live Preview | Source, Split, Edit |
| Markdown | Formatted Document | Source, Split, Edit |
| CSV | Sortable Data Grid | Raw Source, Edit |
| JSON | Interactive Tree | Formatted Raw, Edit |
| SVG & Images | Zoomable Canvas | Raw XML (SVG) |

> Tip: Press \`Ctrl+K\` (or \`⌘K\`) at any time to jump directly to any file in the workspace.
`;

const mimeTypesCsv = `Extension,MIME Type,Category,Preview Mode,Binary
php,application/x-httpd-php,Code,Template Preview & Source,No
html,text/html,Code,Sandboxed Live Preview,No
md,text/markdown,Documentation,Editorial Markdown,No
json,application/json,Structured Data,Collapsible Tree,No
csv,text/csv,Structured Data,Sortable Table Grid,No
svg,image/svg+xml,Vector Media,Zoomable Canvas & XML,No
ts,text/typescript,Code,Syntax Highlighted,No
css,text/css,Code,Syntax Highlighted,No
pdf,application/pdf,Document,Embedded Viewer,Yes
png,image/png,Raster Media,Zoomable Image Canvas,Yes`;

const workspaceJson = `{
  "name": "file-viewer-workspace",
  "layout": {
    "topFrame": {
      "source": "icon.php",
      "heightRatio": "7%",
      "role": "navigation-and-actions"
    },
    "leftFrame": {
      "source": "file.php",
      "widthRatio": "20%",
      "resizable": true,
      "minWidthPx": 200,
      "maxWidthPx": 420
    },
    "mainFrame": {
      "source": "learn.php",
      "widthRatio": "80%",
      "features": ["tabs", "preview", "source", "split", "edit", "find"]
    }
  },
  "supportedEncodings": ["UTF-8", "ASCII", "ISO-8859-1"],
  "defaultFile": "learn.php"
}`;

const framesetDiagramSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 720 420" fill="none">
  <rect width="720" height="420" rx="12" fill="#F8FAFC"/>
  <rect x="24" y="24" width="672" height="372" rx="8" fill="#FFFFFF" stroke="#CBD5E1" stroke-width="1.5"/>
  <!-- Top Frame (7%) -->
  <rect x="24" y="24" width="672" height="52" rx="8" fill="#EFF6FF"/>
  <line x1="24" y1="76" x2="696" y2="76" stroke="#93C5FD" stroke-width="1.5"/>
  <text x="44" y="55" fill="#1E3A8A" font-family="system-ui, sans-serif" font-size="14" font-weight="600">topFrame — icon.php (7% height)</text>
  <text x="676" y="55" text-anchor="end" fill="#3B82F6" font-family="monospace" font-size="12">Header &amp; Actions</text>

  <!-- Left Frame (20%) -->
  <rect x="24" y="76" width="156" height="320" fill="#F8FAFC"/>
  <line x1="180" y1="76" x2="180" y2="396" stroke="#CBD5E1" stroke-width="1.5"/>
  <text x="40" y="110" fill="#0F172A" font-family="system-ui, sans-serif" font-size="13" font-weight="600">leftFrame</text>
  <text x="40" y="130" fill="#64748B" font-family="monospace" font-size="12">file.php (20%)</text>
  <rect x="40" y="152" width="116" height="24" rx="4" fill="#E2E8F0"/>
  <rect x="40" y="186" width="96" height="10" rx="3" fill="#CBD5E1"/>
  <rect x="40" y="208" width="108" height="10" rx="3" fill="#CBD5E1"/>
  <rect x="40" y="230" width="84" height="10" rx="3" fill="#CBD5E1"/>

  <!-- Main Frame (80%) -->
  <text x="210" y="116" fill="#0F172A" font-family="system-ui, sans-serif" font-size="16" font-weight="700">frame — learn.php (80% width)</text>
  <text x="210" y="142" fill="#475569" font-family="system-ui, sans-serif" font-size="13">Primary document inspection, live preview, and syntax-highlighted code pane</text>
  <rect x="210" y="168" width="456" height="196" rx="6" fill="#F8FAFC" stroke="#E2E8F0" stroke-width="1.5"/>
  <rect x="232" y="192" width="180" height="14" rx="3" fill="#CBD5E1"/>
  <rect x="232" y="220" width="390" height="10" rx="3" fill="#E2E8F0"/>
  <rect x="232" y="242" width="350" height="10" rx="3" fill="#E2E8F0"/>
  <rect x="232" y="264" width="372" height="10" rx="3" fill="#E2E8F0"/>
  <rect x="232" y="298" width="120" height="32" rx="6" fill="#2563EB"/>
  <text x="292" y="319" text-anchor="middle" fill="#FFFFFF" font-family="system-ui, sans-serif" font-size="12" font-weight="600">Preview / Code</text>
</svg>`;

const viewerConfigTs = `export interface FrameConfig {
  name: 'topFrame' | 'leftFrame' | 'frame';
  source: string;
  sizeRatio: string;
  resizable: boolean;
}

export const DEFAULT_FRAMESET: FrameConfig[] = [
  { name: 'topFrame', source: 'icon.php', sizeRatio: '7%', resizable: false },
  { name: 'leftFrame', source: 'file.php', sizeRatio: '20%', resizable: true },
  { name: 'frame', source: 'learn.php', sizeRatio: '80%', resizable: true },
];
`;

function makeFile(
  id: string,
  name: string,
  folder: string,
  extension: string,
  language: string,
  category: WorkspaceFile['category'],
  content: string
): WorkspaceFile {
  return {
    id,
    name,
    path: folder ? `${folder}/${name}` : name,
    folder,
    extension,
    language,
    category,
    content,
    sizeBytes: new Blob([content]).size,
    updatedAt: '2026-11-19',
    encoding: 'UTF-8',
    isUserAdded: false,
  };
}

export const INITIAL_WORKSPACE_FILES: WorkspaceFile[] = [
  makeFile('learn-php', 'learn.php', '', 'php', 'PHP / HTML', 'code', learnPhpContent),
  makeFile('file-php', 'file.php', '', 'php', 'PHP / HTML', 'code', filePhpContent),
  makeFile('icon-php', 'icon.php', '', 'php', 'PHP / HTML', 'code', iconPhpContent),
  makeFile('index-html', 'index.html', '', 'html', 'HTML', 'code', framesetHtmlContent),
  makeFile('migration-md', 'migration-guide.md', 'docs', 'md', 'Markdown', 'docs', migrationGuideMd),
  makeFile('mime-csv', 'mime-types.csv', 'data', 'csv', 'CSV', 'data', mimeTypesCsv),
  makeFile('workspace-json', 'workspace.json', 'data', 'json', 'JSON', 'data', workspaceJson),
  makeFile('diagram-svg', 'frameset-diagram.svg', 'assets', 'svg', 'SVG Image', 'media', framesetDiagramSvg),
  makeFile('config-ts', 'frame-config.ts', 'src', 'ts', 'TypeScript', 'code', viewerConfigTs),
];
