import { Language } from '../i18n/translations';

export type TrackId = 'html' | 'css' | 'js' | 'php' | 'mysql';

export interface LearningTrack {
  id: TrackId;
  title: string;
  amharicTitle: string;
  subtitle: string;
  duration: string;
  level: string;
  accentLabel: string;
  objectives: string[];
  starterCode: string;
}

const TRACKS_BY_LANGUAGE: Record<Language, LearningTrack[]> = {
  am: [
    {
      id: 'html',
      title: 'HTML ትምህርት',
      amharicTitle: 'የድረ-ገጽ መሰረታዊ አወቃቀር',
      subtitle: 'ርዕሶችን፣ አንቀጾችን፣ የዝርዝር ማውጫዎችን እና የድረ-ገጽ ክፍሎችን በትክክል ማዋቀር ይማሩ።',
      duration: '45 ደቂቃ',
      level: 'ጀማሪ',
      accentLabel: 'አወቃቀር',
      objectives: [
        'ትክክለኛ የሰነድ መዋቅር (<header>, <main>, <footer>)',
        'የአማርኛ እና የUTF-8 ፊደላት አጠቃቀም',
        'ዝርዝሮች፣ አገናኞች እና ተደራሽ መግለጫዎች',
      ],
      starterCode: `<!DOCTYPE html>
<html lang="am">
<head>
  <meta charset="UTF-8" />
  <style>
    body {
      font-family: 'Noto Sans Ethiopic', system-ui, sans-serif;
      padding: 28px;
      color: #0f172a;
      line-height: 1.7;
    }
    h1 { color: #065f46; margin-bottom: 8px; }
    .card {
      margin-top: 16px;
      padding: 16px 20px;
      border: 1px solid #cbd5e1;
      border-radius: 10px;
      background: #f8fafc;
    }
  </style>
</head>
<body>
  <h1>እንኳን በደህና መጡ — HTML5</h1>
  <p>HTML የማንኛውም ድረ-ገጽ መሰረታዊ አጽም ነው።</p>

  <div class="card">
    <h3>ዋና ዋና ክፍሎች</h3>
    <ul>
      <li><strong>&lt;h1&gt;–&lt;h3&gt;</strong>፡ ግልጽ የርዕስ ደረጃዎች</li>
      <li><strong>&lt;ul&gt; እና &lt;li&gt;</strong>፡ የተደራጁ ዝርዝሮች</li>
      <li><strong>&lt;footer&gt;</strong>፡ የግርጌ እና የአድራሻ መረጃዎች</li>
    </ul>
  </div>
</body>
</html>`,
    },
    {
      id: 'css',
      title: 'CSS ትምህርት',
      amharicTitle: 'የገጽ ውበት እና አቀማመጥ',
      subtitle: 'Flexbox አቀማመጥን፣ ክፍተቶችን፣ ቀለሞችን እና ለስላሳ የገጽ ሽግግሮችን ይለማመዱ።',
      duration: '60 ደቂቃ',
      level: 'ጀማሪ',
      accentLabel: 'ውበት እና ቅርጽ',
      objectives: [
        'የFlexbox ረድፍ አቀማመጥ እና ምላሽ ሰጪ ዲዛይን',
        'ንጹህ ጠርዞች እና የተመጣጠነ ክፍተት',
        'የብርሃን እና የጨለማ ገጽታ ቀለሞች',
      ],
      starterCode: `<!DOCTYPE html>
<html lang="am">
<head>
  <style>
    body {
      font-family: 'Noto Sans Ethiopic', system-ui, sans-serif;
      padding: 28px;
      background: #f8fafc;
      color: #0f172a;
    }
    .grid {
      display: flex;
      gap: 16px;
      flex-wrap: wrap;
      margin-top: 16px;
    }
    .box {
      flex: 1 1 160px;
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 10px;
      padding: 18px;
      transition: transform 0.2s ease, border-color 0.2s ease;
    }
    .box:hover {
      transform: translateY(-3px);
      border-color: #0284c7;
    }
    .title { font-weight: 700; margin-bottom: 6px; color: #0369a1; }
  </style>
</head>
<body>
  <h2>የFlexbox ካርድ አቀማመጥ</h2>
  <p>ለስላሳ እንቅስቃሴውን ለማየት ጠቋሚውን በካርዶቹ ላይ ያሳርፉ።</p>
  <div class="grid">
    <div class="box">
      <div class="title">01. አቀማመጥ</div>
      <div>ተለዋዋጭ ረድፎች እና ዓምዶች</div>
    </div>
    <div class="box">
      <div class="title">02. ክፍተት</div>
      <div>የተመጣጠነ የውስጥ እና የውጭ ስፋት</div>
    </div>
    <div class="box">
      <div class="title">03. ንጽጽር</div>
      <div>በቀላሉ የሚነበብ የቀለም ምርጫ</div>
    </div>
  </div>
</body>
</html>`,
    },
    {
      id: 'js',
      title: 'JavaScript ትምህርት',
      amharicTitle: 'ተግባራዊ የገጽ እንቅስቃሴ',
      subtitle: 'የአዝራር መጫንን ማስተናገድ፣ ሜኑዎችን መክፈት/መዝጋት እና ገጽን በቀጥታ መቀየር ይማሩ።',
      duration: '75 ደቂቃ',
      level: 'መካከለኛ',
      accentLabel: 'ተግባራዊ ሎጂክ',
      objectives: [
        'የDOM ክፍሎችን መምረጥ እና ክስተቶችን ማዳመጥ',
        'ሜኑ እና የብርሃን/ጨለማ ሁነታን መቀያየር',
        'ገጹን ሳይጫኑ መረጃን በቀጥታ ማዘመን',
      ],
      starterCode: `<!DOCTYPE html>
<html lang="am">
<head>
  <style>
    body {
      font-family: 'Noto Sans Ethiopic', system-ui, sans-serif;
      padding: 28px;
      transition: background 0.2s, color 0.2s;
    }
    body.dark {
      background: #0f172a;
      color: #f8fafc;
    }
    button {
      padding: 10px 16px;
      border-radius: 8px;
      border: 1px solid #cbd5e1;
      background: #059669;
      color: white;
      font-weight: 600;
      cursor: pointer;
      margin-right: 8px;
      margin-bottom: 8px;
    }
    .counter {
      margin-top: 20px;
      font-size: 18px;
      font-weight: 600;
    }
  </style>
</head>
<body>
  <h2>ተግባራዊ የJavaScript መቆጣጠሪያዎች</h2>
  <p>ኮዱ እንዴት እንደሚሰራ ለማየት ከታች ያሉትን አዝራሮች ይጫኑ።</p>

  <button onclick="increment()">ነጥብ ጨምር</button>
  <button onclick="toggleTheme()" style="background:#334155;">ጨለማ/ብርሃን ቀይር</button>

  <div class="counter" id="output">የተጠናቀቁ ነጥቦች፡ 0</div>

  <script>
    let count = 0;
    function increment() {
      count += 1;
      document.getElementById('output').textContent = 'የተጠናቀቁ ነጥቦች፡ ' + count;
    }
    function toggleTheme() {
      document.body.classList.toggle('dark');
    }
  </script>
</body>
</html>`,
    },
    {
      id: 'php',
      title: 'PHP ትምህርት',
      amharicTitle: 'የሰርቨር ጎን ፕሮግራሚንግ',
      subtitle: 'ተለዋዋጭ የHTML ቴምፕሌቶችን መፍጠር፣ ገጾችን ማገናኘት እና የሰርቨር መረጃ ማሳየት ይማሩ።',
      duration: '60 ደቂቃ',
      level: 'መካከለኛ',
      accentLabel: 'የሰርቨር ጎን',
      objectives: [
        'የPHP ተለዋዋጮች (Variables) እና ጽሁፍ ማገናኘት',
        'በ <?php echo ... ?> ውጤት ማሳየት',
        'እንደ home.php እና about.php ያሉ ገጾችን ማገናኘት',
      ],
      starterCode: `<?php
$siteName = "አትንኩት ቴክኖሎጂ";
$student = "አትንኩት";
$track = "ሙሉ የድረ-ገጽ ልማት";
?>
<!DOCTYPE html>
<html lang="am">
<head>
  <meta charset="UTF-8" />
  <style>
    body { font-family: 'Noto Sans Ethiopic', system-ui, sans-serif; padding: 28px; color: #0f172a; }
    .panel {
      padding: 20px;
      border: 1px solid #cbd5e1;
      border-radius: 10px;
      background: #f8fafc;
      margin-top: 16px;
      line-height: 1.8;
    }
  </style>
</head>
<body>
  <h2><?php echo $siteName; ?> — የPHP ቴምፕሌት</h2>
  <p>እንኳን በደህና ተመለሱ፣ <strong><?php echo $student; ?></strong>።</p>
  <div class="panel">
    <div>ንቁ ትምህርት፡ <strong><?php echo $track; ?></strong></div>
    <div>የሰርቨር ቀን፡ <?php echo date("M j, Y"); ?></div>
  </div>
</body>
</html>`,
    },
    {
      id: 'mysql',
      title: 'MySQL ትምህርት',
      amharicTitle: 'የውሂብ ጎታ አስተዳደር',
      subtitle: 'የተማሪ እና የትምህርት መረጃዎችን በ SELECT፣ WHERE እና ORDER BY መጠየቅ እና ማጣራት ይማሩ።',
      duration: '60 ደቂቃ',
      level: 'መካከለኛ',
      accentLabel: 'የውሂብ ጎታ',
      objectives: [
        'የሰንጠረዥ አወቃቀር እና ዋና ቁልፎች (Primary Keys)',
        'በ WHERE ትዕዛዝ መረጃዎችን መምረጥ',
        'ውጤቶችን በ ORDER BY ማስተካከል',
      ],
      starterCode: `SELECT id, student_name, track, progress_pct, status
FROM enrollments
WHERE progress_pct >= 60
ORDER BY progress_pct DESC;`,
    },
  ],
  en: [
    {
      id: 'html',
      title: 'HTML LEARN',
      amharicTitle: 'Web Document Structure',
      subtitle: 'Structure headings, paragraphs, navigation lists, and semantic sections cleanly.',
      duration: '45 min',
      level: 'Beginner',
      accentLabel: 'Markup',
      objectives: [
        'Semantic document structure (<header>, <main>, <footer>)',
        'Multilingual UTF-8 typography support',
        'Lists, links, and accessible descriptions',
      ],
      starterCode: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <style>
    body {
      font-family: system-ui, sans-serif;
      padding: 28px;
      color: #0f172a;
      line-height: 1.6;
    }
    h1 { color: #065f46; margin-bottom: 8px; }
    .card {
      margin-top: 16px;
      padding: 16px 20px;
      border: 1px solid #cbd5e1;
      border-radius: 10px;
      background: #f8fafc;
    }
  </style>
</head>
<body>
  <h1>Welcome — HTML5</h1>
  <p>HTML builds the skeleton of every web page.</p>

  <div class="card">
    <h3>Key Elements</h3>
    <ul>
      <li><strong>&lt;h1&gt;–&lt;h3&gt;</strong>: Clear section hierarchy</li>
      <li><strong>&lt;ul&gt; &amp; &lt;li&gt;</strong>: Organized navigation lists</li>
      <li><strong>&lt;footer&gt;</strong>: Contact and copyright details</li>
    </ul>
  </div>
</body>
</html>`,
    },
    {
      id: 'css',
      title: 'CSS LEARN',
      amharicTitle: 'Styling & Layout',
      subtitle: 'Master Flexbox layouts, responsive grids, spacing, and smooth UI transitions.',
      duration: '60 min',
      level: 'Beginner',
      accentLabel: 'Styling',
      objectives: [
        'Flexbox row alignment and responsive wrapping',
        'Clean hairline borders and consistent padding ratios',
        'Light and dark surface color tokens',
      ],
      starterCode: `<!DOCTYPE html>
<html lang="en">
<head>
  <style>
    body {
      font-family: system-ui, sans-serif;
      padding: 28px;
      background: #f8fafc;
      color: #0f172a;
    }
    .grid {
      display: flex;
      gap: 16px;
      flex-wrap: wrap;
      margin-top: 16px;
    }
    .box {
      flex: 1 1 160px;
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 10px;
      padding: 18px;
      transition: transform 0.2s ease, border-color 0.2s ease;
    }
    .box:hover {
      transform: translateY(-3px);
      border-color: #0284c7;
    }
    .title { font-weight: 700; margin-bottom: 6px; color: #0369a1; }
  </style>
</head>
<body>
  <h2>Flexbox Card Layout</h2>
  <p>Hover over each card to observe smooth transitions.</p>
  <div class="grid">
    <div class="box">
      <div class="title">01. Layout</div>
      <div>Flexible rows &amp; columns</div>
    </div>
    <div class="box">
      <div class="title">02. Spacing</div>
      <div>Consistent padding rhythm</div>
    </div>
    <div class="box">
      <div class="title">03. Contrast</div>
      <div>Readable color hierarchy</div>
    </div>
  </div>
</body>
</html>`,
    },
    {
      id: 'js',
      title: 'JAVA SCRIPT',
      amharicTitle: 'Interactive Logic',
      subtitle: 'Handle button clicks, toggle menus, update DOM state, and build interactive tools.',
      duration: '75 min',
      level: 'Intermediate',
      accentLabel: 'Logic',
      objectives: [
        'DOM selection and event listeners',
        'Class toggling for menus and light/dark themes',
        'Dynamic state updates without page reloads',
      ],
      starterCode: `<!DOCTYPE html>
<html lang="en">
<head>
  <style>
    body {
      font-family: system-ui, sans-serif;
      padding: 28px;
      transition: background 0.2s, color 0.2s;
    }
    body.dark {
      background: #0f172a;
      color: #f8fafc;
    }
    button {
      padding: 10px 16px;
      border-radius: 8px;
      border: 1px solid #cbd5e1;
      background: #059669;
      color: white;
      font-weight: 600;
      cursor: pointer;
      margin-right: 8px;
    }
    .counter {
      margin-top: 20px;
      font-size: 18px;
      font-weight: 600;
    }
  </style>
</head>
<body>
  <h2>Interactive DOM Controls</h2>
  <p>Click the buttons below to run real JavaScript handlers.</p>

  <button onclick="increment()">Add Lesson Point</button>
  <button onclick="toggleTheme()" style="background:#334155;">Toggle Dark Mode</button>

  <div class="counter" id="output">Completed Points: 0</div>

  <script>
    let count = 0;
    function increment() {
      count += 1;
      document.getElementById('output').textContent = 'Completed Points: ' + count;
    }
    function toggleTheme() {
      document.body.classList.toggle('dark');
    }
  </script>
</body>
</html>`,
    },
    {
      id: 'php',
      title: 'PHP',
      amharicTitle: 'Server-Side Templates',
      subtitle: 'Generate dynamic HTML templates, reuse page headers, and process form requests.',
      duration: '60 min',
      level: 'Intermediate',
      accentLabel: 'Backend',
      objectives: [
        'PHP variables and string interpolation',
        'Template rendering with <?php echo ... ?>',
        'Connecting navigation pages like home.php and about.php',
      ],
      starterCode: `<?php
$siteName = "Atinkut Technology";
$student = "Atinkut";
$track = "Full-Stack Web";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <style>
    body { font-family: system-ui, sans-serif; padding: 28px; color: #0f172a; }
    .panel {
      padding: 20px;
      border: 1px solid #cbd5e1;
      border-radius: 10px;
      background: #f8fafc;
      margin-top: 16px;
    }
  </style>
</head>
<body>
  <h2><?php echo $siteName; ?> — PHP Template</h2>
  <p>Welcome back, <strong><?php echo $student; ?></strong>.</p>
  <div class="panel">
    <div>Active Track: <strong><?php echo $track; ?></strong></div>
    <div>Server Date: <?php echo date("M j, Y"); ?></div>
  </div>
</body>
</html>`,
    },
    {
      id: 'mysql',
      title: 'MySQL',
      amharicTitle: 'Database Queries',
      subtitle: 'Query structured student and course records with SELECT, WHERE, and ORDER BY.',
      duration: '60 min',
      level: 'Intermediate',
      accentLabel: 'Database',
      objectives: [
        'Relational table schemas with primary keys',
        'Filtering records using WHERE clauses',
        'Sorting query results with ORDER BY',
      ],
      starterCode: `SELECT id, student_name, track, progress_pct, status
FROM enrollments
WHERE progress_pct >= 60
ORDER BY progress_pct DESC;`,
    },
  ],
  om: [
    {
      id: 'html',
      title: 'Barnoota HTML',
      amharicTitle: 'Caasaa Bu’uuraa Weebii',
      subtitle: 'Mata-duree, keeyyata, tarreewwan fi kutaalee fuula weebii sirnaan ijaaruu baradhaa.',
      duration: 'Daqiiqaa 45',
      level: 'Jalqabaa',
      accentLabel: 'Caasaa',
      objectives: [
        'Caasaa galmee sirrii (<header>, <main>, <footer>)',
        'Itti fayyadama qubee UTF-8 afaanota hedduuf',
        'Tarreewwan, geessituu fi ibsa ifaa',
      ],
      starterCode: `<!DOCTYPE html>
<html lang="om">
<head>
  <meta charset="UTF-8" />
  <style>
    body {
      font-family: system-ui, sans-serif;
      padding: 28px;
      color: #0f172a;
      line-height: 1.65;
    }
    h1 { color: #065f46; margin-bottom: 8px; }
    .card {
      margin-top: 16px;
      padding: 16px 20px;
      border: 1px solid #cbd5e1;
      border-radius: 10px;
      background: #f8fafc;
    }
  </style>
</head>
<body>
  <h1>Baga Nagaan Dhuftan — HTML5</h1>
  <p>HTML lafee dugdaa fuula weebii kamiyyuu ti.</p>

  <div class="card">
    <h3>Kutaalee Ijoo</h3>
    <ul>
      <li><strong>&lt;h1&gt;–&lt;h3&gt;</strong>: Sadarkaa mata-duree ifaa</li>
      <li><strong>&lt;ul&gt; fi &lt;li&gt;</strong>: Tarreewwan qindaa’oo</li>
      <li><strong>&lt;footer&gt;</strong>: Odeeffannoo teessoo fi mirgaa</li>
    </ul>
  </div>
</body>
</html>`,
    },
    {
      id: 'css',
      title: 'Barnoota CSS',
      amharicTitle: 'Miidhaginaa fi Qindaa’ina',
      subtitle: 'Qindaa’ina Flexbox, iddoo duwwaa, halluuwwan fi jijjiirama suutaawaa shaakalaa.',
      duration: 'Daqiiqaa 60',
      level: 'Jalqabaa',
      accentLabel: 'Miidhagina',
      objectives: [
        'Qindaa’ina sarara Flexbox fi dizaayinii madaalawaa',
        'Daangaa qulqulluu fi iddoo wal-fakkaatu',
        'Halluuwwan bifa ifaa fi dukkanaa',
      ],
      starterCode: `<!DOCTYPE html>
<html lang="om">
<head>
  <style>
    body {
      font-family: system-ui, sans-serif;
      padding: 28px;
      background: #f8fafc;
      color: #0f172a;
    }
    .grid {
      display: flex;
      gap: 16px;
      flex-wrap: wrap;
      margin-top: 16px;
    }
    .box {
      flex: 1 1 160px;
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 10px;
      padding: 18px;
      transition: transform 0.2s ease, border-color 0.2s ease;
    }
    .box:hover {
      transform: translateY(-3px);
      border-color: #0284c7;
    }
    .title { font-weight: 700; margin-bottom: 6px; color: #0369a1; }
  </style>
</head>
<body>
  <h2>Qindaa’ina Kaardii Flexbox</h2>
  <p>Sochii isaa ilaaluuf kaardiiwwan irratti tuqaa.</p>
  <div class="grid">
    <div class="box">
      <div class="title">01. Qindaa’ina</div>
      <div>Sararoota fi utubaawwan jijjiiraman</div>
    </div>
    <div class="box">
      <div class="title">02. Iddoo</div>
      <div>Bal’ina keessaa madaalawaa</div>
    </div>
    <div class="box">
      <div class="title">03. Iftoomina</div>
      <div>Halluu salphaatti dubbifamu</div>
    </div>
  </div>
</body>
</html>`,
    },
    {
      id: 'js',
      title: 'Barnoota JavaScript',
      amharicTitle: 'Loojikii Gochaa',
      subtitle: 'Cuqaasuu qabduu, banuu/cufuu tarree fi jijjiirama DOM kallattii baradhaa.',
      duration: 'Daqiiqaa 75',
      level: 'Giddu-galeessaa',
      accentLabel: 'Loojikii',
      objectives: [
        'Filannoo DOM fi dhaggeeffattoota taatee',
        'Tarree fi bifa dukkanaa/ifaa jijjiiruu',
        'Fuula osoo hin haaromsin deetaa fooyyessuu',
      ],
      starterCode: `<!DOCTYPE html>
<html lang="om">
<head>
  <style>
    body {
      font-family: system-ui, sans-serif;
      padding: 28px;
      transition: background 0.2s, color 0.2s;
    }
    body.dark {
      background: #0f172a;
      color: #f8fafc;
    }
    button {
      padding: 10px 16px;
      border-radius: 8px;
      border: 1px solid #cbd5e1;
      background: #059669;
      color: white;
      font-weight: 600;
      cursor: pointer;
      margin-right: 8px;
    }
    .counter {
      margin-top: 20px;
      font-size: 18px;
      font-weight: 600;
    }
  </style>
</head>
<body>
  <h2>To’annoo DOM Gochaa</h2>
  <p>Koodiin JavaScript akkamitti akka hojjetu ilaaluuf cuqaasaa.</p>

  <button onclick="increment()">Qabxii Dabali</button>
  <button onclick="toggleTheme()" style="background:#334155;">Bifa Dukkanaa Jijjiiri</button>

  <div class="counter" id="output">Qabxii Xumurame: 0</div>

  <script>
    let count = 0;
    function increment() {
      count += 1;
      document.getElementById('output').textContent = 'Qabxii Xumurame: ' + count;
    }
    function toggleTheme() {
      document.body.classList.toggle('dark');
    }
  </script>
</body>
</html>`,
    },
    {
      id: 'php',
      title: 'Barnoota PHP',
      amharicTitle: 'Piroogiraamingii Sarvarii',
      subtitle: 'Tempileetii HTML jijjiiramaa uumuu, fuulota wal-qabsiisuu fi unkawwan keessummeessuu baradhaa.',
      duration: 'Daqiiqaa 60',
      level: 'Giddu-galeessaa',
      accentLabel: 'Sarvarii',
      objectives: [
        'Jijjiiramoota PHP fi wal-itti hidhuu jechootaa',
        'Bu’aa <?php echo ... ?> tiin baasuu',
        'Fuulota akka home.php fi about.php wal-qabsiisuu',
      ],
      starterCode: `<?php
$siteName = "Teknooloojii Atinkut";
$student = "Atinkut";
$track = "Misooma Weebii Guutuu";
?>
<!DOCTYPE html>
<html lang="om">
<head>
  <meta charset="UTF-8" />
  <style>
    body { font-family: system-ui, sans-serif; padding: 28px; color: #0f172a; }
    .panel {
      padding: 20px;
      border: 1px solid #cbd5e1;
      border-radius: 10px;
      background: #f8fafc;
      margin-top: 16px;
    }
  </style>
</head>
<body>
  <h2><?php echo $siteName; ?> — Tempileetii PHP</h2>
  <p>Baga nagaan deebitan, <strong><?php echo $student; ?></strong>.</p>
  <div class="panel">
    <div>Barnoota Hojii Irra Jiru: <strong><?php echo $track; ?></strong></div>
    <div>Guyyaa Sarvarii: <?php echo date("M j, Y"); ?></div>
  </div>
</body>
</html>`,
    },
    {
      id: 'mysql',
      title: 'Barnoota MySQL',
      amharicTitle: 'Bulchiinsa Kuusaa Deetaa',
      subtitle: 'Galmee barattootaa fi koorsiiwwanii SELECT, WHERE fi ORDER BY fayyadamuun gaafachuu baradhaa.',
      duration: 'Daqiiqaa 60',
      level: 'Giddu-galeessaa',
      accentLabel: 'Kuusaa Deetaa',
      objectives: [
        'Caasaa gabatee fi furtuuwwan ijoo (Primary Keys)',
        'WHERE fayyadamuun ragaalee calaluu',
        'Bu’aawwan ORDER BY tiin tartiibessuu',
      ],
      starterCode: `SELECT id, student_name, track, progress_pct, status
FROM enrollments
WHERE progress_pct >= 60
ORDER BY progress_pct DESC;`,
    },
  ],
};

export function getLearningTracks(lang: Language): LearningTrack[] {
  return TRACKS_BY_LANGUAGE[lang];
}

export interface EnrollmentRow {
  id: number;
  student_name: string;
  track: string;
  lessons_done: number;
  progress_pct: number;
  status: 'Active' | 'Completed';
}

export const SAMPLE_ENROLLMENTS: EnrollmentRow[] = [
  { id: 101, student_name: 'አትንኩት ገነት / Atinkut', track: 'HTML & CSS', lessons_done: 12, progress_pct: 100, status: 'Completed' },
  { id: 102, student_name: 'አበበ ቢቂላ / Abebe', track: 'JavaScript', lessons_done: 9, progress_pct: 75, status: 'Active' },
  { id: 103, student_name: 'ሰላማዊት ታደሰ / Selam', track: 'PHP', lessons_done: 8, progress_pct: 80, status: 'Active' },
  { id: 104, student_name: 'ዳዊት መኮንን / Dawit', track: 'MySQL', lessons_done: 5, progress_pct: 50, status: 'Active' },
  { id: 105, student_name: 'ሃና ተስፋዬ / Hanna', track: 'HTML & CSS', lessons_done: 11, progress_pct: 92, status: 'Active' },
  { id: 106, student_name: 'ዮሐንስ ከበደ / Yohannes', track: 'PHP & MySQL', lessons_done: 10, progress_pct: 83, status: 'Active' },
];
